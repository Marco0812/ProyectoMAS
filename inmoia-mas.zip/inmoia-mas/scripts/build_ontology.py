"""Genera ontologia/inmoia.owl (OWL 2, RDF/XML) a partir de la TBox del Proyecto 3.

Conserva las 14 clases, 10 propiedades de objeto y 13 de datos de
P3_ontologia_InmoIA.owx (mismos IRIs) y agrega los axiomas que en el P3
quedaron solo como propuesta: cardinalidades, clases disjuntas, relaciones
inversas y restricciones de rango de datos. Esos axiomas son las reglas
duras que HermiT hace cumplir en tiempo de ejecución.

Uso:  python scripts/build_ontology.py
"""
from pathlib import Path

from owlready2 import (AllDisjoint, AnnotationProperty, ConstrainedDatatype,
                       DataProperty, FunctionalProperty, ObjectProperty, Thing,
                       World)

IRI = "https://example.org/inmoia/ontologia#"
SALIDA = Path(__file__).resolve().parent.parent / "ontologia" / "inmoia.owl"


def construir() -> Path:
    world = World()
    onto = world.get_ontology(IRI)
    with onto:
        class axiomaId(AnnotationProperty):
            pass

        # ---------- Clases del P3 ----------
        class Persona(Thing): pass
        class Cliente(Persona): pass
        class Inmueble(Thing): pass
        class Casa(Inmueble): pass
        class Departamento(Inmueble): pass
        class Ubicacion(Thing): pass
        class Preferencia(Thing): pass
        class Requisito(Thing): pass
        class Recomendacion(Thing): pass
        class Agente(Thing): pass
        class AgentePrecio(Agente): pass
        class AgenteUbicacion(Agente): pass
        class AgenteCaracteristicas(Agente): pass
        class AgenteIntegrador(Agente): pass

        # ---------- Clases nuevas (proyecto final) ----------
        class AgenteValidador(Agente):
            comment = ["Agente que valida solicitudes y recomendaciones contra la TBox con HermiT."]

        class InmuebleViable(Inmueble):
            comment = ["Inmueble que cumple todos los requisitos obligatorios de una solicitud. "
                       "Su definición (equivalentTo) se materializa en RAM por cada solicitud."]

        class FueraDePresupuesto(Inmueble):
            comment = ["Definición paramétrica efímera: Inmueble ⊓ ∃precio.decimal[> presupuestoMaximo]."]

        class HabitacionesInsuficientes(Inmueble):
            comment = ["Definición paramétrica efímera: Inmueble ⊓ ∃habitaciones.integer[< minHabitaciones]."]

        class TipoNoSolicitado(Inmueble):
            comment = ["Definición paramétrica efímera: Inmueble ⊓ ¬(tipo requerido)."]

        class SinEstacionamientoRequerido(Inmueble):
            comment = ["Definición paramétrica efímera: Inmueble ⊓ (estacionamiento value false)."]

        # ---------- Propiedades de objeto (P3 + inversas) ----------
        class tienePreferencia(ObjectProperty): domain = [Cliente]; range = [Preferencia]
        class esPreferenciaDe(ObjectProperty): domain = [Preferencia]; range = [Cliente]; inverse_property = tienePreferencia
        class tieneRequisito(ObjectProperty): domain = [Cliente]; range = [Requisito]
        class esRequisitoDe(ObjectProperty): domain = [Requisito]; range = [Cliente]; inverse_property = tieneRequisito
        class estaUbicadoEn(ObjectProperty, FunctionalProperty): domain = [Inmueble]; range = [Ubicacion]
        class contieneInmueble(ObjectProperty): domain = [Ubicacion]; range = [Inmueble]; inverse_property = estaUbicadoEn
        class generaRecomendacion(ObjectProperty): domain = [AgenteIntegrador]; range = [Recomendacion]
        class recomiendaInmueble(ObjectProperty, FunctionalProperty): domain = [Recomendacion]; range = [Inmueble]
        class dirigidaA(ObjectProperty, FunctionalProperty): domain = [Recomendacion]; range = [Cliente]
        class tieneRecomendacion(ObjectProperty): domain = [Cliente]; range = [Recomendacion]; inverse_property = dirigidaA
        class evaluaInmueble(ObjectProperty): domain = [Agente]; range = [Inmueble]

        # ---------- Propiedades de datos (P3 + nuevas) ----------
        class nombre(DataProperty, FunctionalProperty): domain = [Cliente]; range = [str]
        class presupuestoMaximo(DataProperty, FunctionalProperty): domain = [Cliente]; range = [float]
        class minHabitaciones(DataProperty, FunctionalProperty): domain = [Cliente]; range = [int]
        class requiereEstacionamiento(DataProperty, FunctionalProperty): domain = [Cliente]; range = [bool]
        class precio(DataProperty, FunctionalProperty): domain = [Inmueble]; range = [float]
        class habitaciones(DataProperty, FunctionalProperty): domain = [Inmueble]; range = [int]
        class banos(DataProperty, FunctionalProperty): domain = [Inmueble]; range = [int]
        class metrosCuadrados(DataProperty, FunctionalProperty): domain = [Inmueble]; range = [float]
        class estacionamiento(DataProperty, FunctionalProperty): domain = [Inmueble]; range = [bool]
        class direccionGeneral(DataProperty): domain = [Ubicacion]; range = [str]
        class nombreZona(DataProperty, FunctionalProperty): domain = [Ubicacion]; range = [str]
        class descripcionPreferencia(DataProperty): domain = [Preferencia]; range = [str]
        class descripcionRequisito(DataProperty): domain = [Requisito]; range = [str]
        class puntaje(DataProperty, FunctionalProperty): domain = [Recomendacion]; range = [float]
        class motivo(DataProperty): domain = [Recomendacion]; range = [str]

        # ---------- Axiomas duros (los hace cumplir HermiT) ----------
        # AX1: todo cliente declara un presupuesto positivo
        Cliente.is_a.append(presupuestoMaximo.some(ConstrainedDatatype(float, min_exclusive=0.0)))
        # AX2: todo inmueble tiene precio positivo
        Inmueble.is_a.append(precio.some(ConstrainedDatatype(float, min_exclusive=0.0)))
        # AX3: Casa y Departamento son disjuntas (P3, tabla 2.5)
        AllDisjoint([Casa, Departamento])
        # AX4: cardinalidades de Recomendacion (P3, tabla 2.4)
        Recomendacion.is_a.append(recomiendaInmueble.exactly(1, Inmueble))
        Recomendacion.is_a.append(dirigidaA.exactly(1, Cliente))
        # AX5: solo se recomiendan inmuebles viables
        Recomendacion.is_a.append(recomiendaInmueble.only(InmuebleViable))
        # AX6: disjunciones conceptuales aceptadas en el P3
        AllDisjoint([Cliente, Agente])
        AllDisjoint([Preferencia, Requisito])

        Cliente.comment = ["AX1: Cliente ⊑ ∃presupuestoMaximo.decimal[> 0]"]
        Inmueble.comment = ["AX2: Inmueble ⊑ ∃precio.decimal[> 0]"]
        Recomendacion.comment = ["AX4: Recomendacion ⊑ =1 recomiendaInmueble ⊓ =1 dirigidaA",
                                 "AX5: Recomendacion ⊑ ∀recomiendaInmueble.InmuebleViable"]
        Casa.comment = ["AX3: Casa ⊓ Departamento ⊑ ⊥"]

    onto.metadata.comment = ["InmoIA - TBox del sistema multiagente (proyecto final). "
                             "Extiende P3_ontologia_InmoIA.owx."]
    SALIDA.parent.mkdir(parents=True, exist_ok=True)
    onto.save(file=str(SALIDA), format="rdfxml")
    return SALIDA


if __name__ == "__main__":
    ruta = construir()
    print(f"Ontología guardada en {ruta}")
