"""Ejecuta la Crew de InmoIA contra el backend (demo en vivo).

Ejemplos:
  python scripts/run_crew.py --caso C01            # caso de prueba 1: resolución exitosa
  python scripts/run_crew.py --caso R02            # caso de prueba 2: rechazo semántico
  python scripts/run_crew.py --perfil '{"max_precio": 3000000, "min_habs": 2}'
  python scripts/run_crew.py --caso C01 --simulado # sin API key (LLM determinista)

Requiere el backend activo:  uvicorn inmoia.api.main:app
"""
import argparse
import json
import os
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("CREWAI_DISABLE_TELEMETRY", "true")
os.environ.setdefault("CREWAI_TRACING_ENABLED", "false")
os.environ.setdefault("OTEL_SDK_DISABLED", "true")

import httpx  # noqa: E402

from inmoia import config  # noqa: E402
from inmoia.agents.crew import crear_crew  # noqa: E402


def cargar_perfil(args) -> dict:
    if args.perfil:
        return json.loads(args.perfil)
    casos = json.loads(config.CASOS_PATH.read_text(encoding="utf-8"))
    for caso in casos["validos"] + casos["rechazo"]:
        if caso["id"] == args.caso:
            print(f"Caso {caso['id']}: {caso['descripcion']}")
            return caso["perfil"]
    sys.exit(f"No existe el caso {args.caso}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--caso", default="C01")
    ap.add_argument("--perfil", help="JSON con el perfil del cliente")
    ap.add_argument("--simulado", action="store_true", help="usa el LLM determinista (sin API key)")
    args = ap.parse_args()

    api = httpx.Client(base_url=config.API_URL, timeout=120)
    try:
        api.get("/health").raise_for_status()
    except httpx.HTTPError:
        sys.exit(f"El backend no responde en {config.API_URL}. Ejecuta: uvicorn inmoia.api.main:app")

    llm = None
    if args.simulado:
        from inmoia.agents.simulado import ScriptedLLM
        llm = ScriptedLLM()
    elif not os.getenv("ANTHROPIC_API_KEY"):
        sys.exit("Falta ANTHROPIC_API_KEY en .env (o usa --simulado).")

    perfil = cargar_perfil(args)
    sol = api.post("/solicitudes", json={"perfil": perfil}).json()
    sid = sol["id"]
    print(f"Solicitud {sid} creada · LLM: {'simulado' if llm else config.LLM_MODEL}\n")

    resultado = crear_crew(sid, llm=llm).kickoff()

    estado = api.get(f"/solicitudes/{sid}").json()["estado"]
    if estado == "RECOMENDADA":
        api.post(f"/solicitudes/{sid}/explicacion", json={"texto": str(resultado.raw)})
    trazas = api.get("/auditoria/trazas", params={"solicitud_id": sid}).json()

    print("\n" + "=" * 70)
    print(f"Solicitud {sid} → estado final: {estado}")
    if estado == "RECOMENDADA":
        rec = api.get(f"/solicitudes/{sid}/recomendacion").json()
        for i, r in enumerate(rec["top3"], 1):
            print(f"  {i}. {r['id']}  U={r['puntaje']}  aportes={r['aportes']}")
        print(f"  Verificación AX5 (HermiT): {rec['validacion_ax5']}")
    else:
        val = api.get(f"/solicitudes/{sid}").json().get("validacion", {})
        for v in val.get("violaciones", []):
            print(f"  ✗ {v['axioma']}: {v['texto']}  [{v.get('individuo')}]")
            if v.get("detalle"):
                print(f"    {v['detalle']}")
    print(f"Trazas en MongoDB: {dict(Counter(t['evento'] for t in trazas))}")
    print(f"Ver: {config.API_URL}/auditoria/trazas?solicitud_id={sid}")


if __name__ == "__main__":
    main()
