"""Carga (o recarga) el catálogo sintético en MongoDB, validado por HermiT.

  python scripts/seed_db.py           # solo si la colección está vacía
  python scripts/seed_db.py --forzar  # borra y recarga
"""
import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from inmoia import config, db  # noqa: E402
from inmoia.api.main import sembrar_catalogo  # noqa: E402


async def main(forzar: bool):
    print(f"Backend: {config.DB_BACKEND} · base: {config.MONGODB_DB}")
    print("Ping:", await db.ping())
    await db.crear_indices()
    n = await sembrar_catalogo(forzar=forzar)
    print(f"Inmuebles cargados: {n}" if n else "La colección ya tenía datos (usa --forzar).")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--forzar", action="store_true")
    asyncio.run(main(ap.parse_args().forzar))
