"""Auditoría de Shapley: calcula φ_i de los 5 agentes, la guarda en MongoDB
(vía API) y genera results/shapley.json y results/shapley.png.

  python scripts/shapley_eval.py          # usa el backend (guarda en MongoDB)
  python scripts/shapley_eval.py --local  # sin backend
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx  # noqa: E402
import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from inmoia import config  # noqa: E402
from inmoia.evaluacion import AGENTES, auditoria_shapley  # noqa: E402


def graficar(res: dict, ruta: Path):
    orden = sorted(res["phi"], key=lambda a: res["phi"][a])
    valores = [res["phi"][a] for a in orden]
    etiquetas = [f"{a} · {AGENTES[a]}" for a in orden]
    fig, ax = plt.subplots(figsize=(8, 3.6), dpi=200)
    barras = ax.barh(etiquetas, valores, color="#2a4a6b", height=0.55)
    for b, v in zip(barras, valores):
        ax.text(v + 0.4, b.get_y() + b.get_height() / 2, f"{v:.1f}", va="center",
                fontsize=9, color="#222")
    ax.set_xlabel("φᵢ (puntos de q, escala 0-100)", fontsize=9, color="#444")
    ax.set_title(f"Contribución marginal (Shapley) · v(N) = {res['v_N']:.1f} = Σφᵢ",
                 fontsize=11, loc="left", color="#111")
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.spines["left"].set_color("#bbb")
    ax.spines["bottom"].set_color("#bbb")
    ax.tick_params(colors="#333", labelsize=9)
    ax.xaxis.grid(True, color="#eee")
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(ruta)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--local", action="store_true")
    args = ap.parse_args()
    if args.local:
        res = auditoria_shapley()
    else:
        res = httpx.post(f"{config.API_URL}/auditoria/shapley", timeout=300).json()
    config.RESULTS_DIR.mkdir(exist_ok=True)
    (config.RESULTS_DIR / "shapley.json").write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                                     encoding="utf-8")
    graficar(res, config.RESULTS_DIR / "shapley.png")
    print(f"v(N) = {res['v_N']}   Σφ = {res['suma_phi']}  (eficiencia)")
    for a, v in sorted(res["phi"].items(), key=lambda kv: -kv[1]):
        print(f"  φ[{a}] {AGENTES[a]:<32} {v:7.2f}")
    print("Guardado en results/shapley.json y results/shapley.png")


if __name__ == "__main__":
    main()
