"""Benchmark: CRUD en MongoDB vs inferencia semántica (HermiT) + tasa de éxito.

  python scripts/benchmark.py --n 20

Requiere el backend activo. Ejecútenlo contra Atlas antes de presentar:
los tiempos CRUD dependen de la red (memoria local ≈ 1-3 ms; Atlas ≈ 20-150 ms).
"""
import argparse
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx  # noqa: E402

from inmoia import config  # noqa: E402


def medir(fn, n):
    tiempos = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        tiempos.append((time.perf_counter() - t0) * 1000)
    tiempos.sort()
    return {"n": n, "media_ms": round(statistics.mean(tiempos), 2),
            "mediana_ms": round(statistics.median(tiempos), 2),
            "p95_ms": round(tiempos[max(0, int(0.95 * n) - 1)], 2)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=20)
    n = ap.parse_args().n
    api = httpx.Client(base_url=config.API_URL, timeout=120)
    salud = api.get("/health").json()
    casos = json.loads(config.CASOS_PATH.read_text(encoding="utf-8"))
    perfil = casos["validos"][0]["perfil"]
    sid = api.post("/solicitudes", json={"perfil": perfil}).json()["id"]

    def crear_y_borrar():
        api.post("/solicitudes", json={"perfil": perfil})

    res = {
        "backend_db": salud["mongo"]["backend"],
        "crud": {
            "GET /propiedades (lista)": medir(lambda: api.get("/propiedades"), n),
            "GET /propiedades/{id}": medir(lambda: api.get("/propiedades/P07"), n),
            "POST /solicitudes (insert)": medir(crear_y_borrar, n),
        },
        "inferencia": {
            "POST /solicitudes/{id}/validar (HermiT)": medir(
                lambda: api.post(f"/solicitudes/{sid}/validar"), n),
        },
    }
    for c in config.CRITERIOS:
        api.post(f"/solicitudes/{sid}/evaluar/{c}")
    res["inferencia"]["POST /solicitudes/{id}/consenso (+ guardia AX5)"] = medir(
        lambda: api.post(f"/solicitudes/{sid}/consenso"), max(3, n // 4))

    # Tasa de éxito sobre los 11 casos (8 válidos + 3 de rechazo)
    exitos, detalle = 0, []
    for caso in casos["validos"] + casos["rechazo"]:
        s = api.post("/solicitudes", json={"perfil": caso["perfil"]}).json()["id"]
        val = api.post(f"/solicitudes/{s}/validar").json()
        esperado = caso.get("esperado", "APROBADA")
        ok = val["estado"] == esperado
        if ok and esperado == "APROBADA":
            for c in config.CRITERIOS:
                api.post(f"/solicitudes/{s}/evaluar/{c}")
            r = api.post(f"/solicitudes/{s}/consenso")
            ok = r.status_code == 200 and len(r.json()["top3"]) > 0
        exitos += ok
        detalle.append({"caso": caso["id"], "esperado": esperado, "obtenido": val["estado"], "ok": ok})
    res["tasa_exito"] = {"exitos": exitos, "total": len(detalle),
                         "porcentaje": round(100 * exitos / len(detalle), 1), "detalle": detalle}

    config.RESULTS_DIR.mkdir(exist_ok=True)
    (config.RESULTS_DIR / "benchmark.json").write_text(json.dumps(res, ensure_ascii=False, indent=2),
                                                       encoding="utf-8")
    print(f"Base de datos: {res['backend_db']}")
    for grupo in ("crud", "inferencia"):
        print(f"\n{grupo.upper()}")
        for k, v in res[grupo].items():
            print(f"  {k:<48} media {v['media_ms']:>8} ms   p95 {v['p95_ms']:>8} ms")
    t = res["tasa_exito"]
    print(f"\nTasa de éxito: {t['exitos']}/{t['total']} = {t['porcentaje']}%")
    print("Guardado en results/benchmark.json")


if __name__ == "__main__":
    main()
