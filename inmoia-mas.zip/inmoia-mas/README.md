# InmoIA — Asesor inmobiliario multiagente

Sistema multiagente (MAS) que recomienda casas y departamentos en Puebla según presupuesto, zona y características. Integra **CrewAI** (5 agentes), un backend asíncrono **FastAPI**, persistencia en **MongoDB Atlas** y una ontología **OWL 2** que el razonador **HermiT** evalúa en RAM por cada petición. Para la explicabilidad, cada acción queda en trazas de auditoría y la contribución de cada agente se mide con **valores de Shapley**.

> Proyecto final · Agentes Inteligentes (13012A-O26) · Universidad Iberoamericana Puebla · Otoño 2026
> Manuel Antonio Guzman Sanchez (191478) · Marco Uriel Castaneda-Avila (196837)

---

## 1. Idea central: separar conocimiento y código

| Capa | Qué contiene | Dónde vive |
|---|---|---|
| Conocimiento declarativo | Reglas duras del dominio (AX1–AX5): presupuesto positivo, Casa ⊓ Departamento ⊑ ⊥, "solo se recomiendan inmuebles viables" | `ontologia/inmoia.owl` (TBox) |
| Datos transaccionales | Catálogo, solicitudes, evaluaciones, recomendaciones, trazas | MongoDB Atlas |
| Código procedimental | Puntuaciones blandas (0-100), consenso ponderado, orquestación | `inmoia/` (Python) |
| Razonamiento generativo | Interpretar resultados y explicarlos al cliente | Agentes CrewAI + Claude |

Para cambiar una regla de negocio basta con editar la ontología; no hace falta tocar Python. Los esquemas Pydantic solo validan **tipos**. Por eso un presupuesto negativo pasa la API y lo rechaza la ontología, con justificación lógica.

## 2. Arquitectura

![Arquitectura](docs/arquitectura.png)

**Crew (Process.sequential):**

| # | Agente | Herramienta (`@tool` + httpx) | Endpoint |
|---|---|---|---|
| T0 | A5 Validador Semántico | `Validar solicitud con la ontologia` | `POST /solicitudes/{id}/validar` |
| T1 | A1 Analista de Precio | `Evaluar criterio inmobiliario` | `POST /solicitudes/{id}/evaluar/precio` |
| T2 | A2 Analista de Zona | `Evaluar criterio inmobiliario` | `POST /solicitudes/{id}/evaluar/zona` |
| T3 | A3 Analista de Vivienda | `Evaluar criterio inmobiliario` | `POST /solicitudes/{id}/evaluar/vivienda` |
| T4 | A4 Integrador | `Consenso inmobiliario` | `POST /solicitudes/{id}/consenso` |

T1–T4 son `ConditionalTask`: solo se ejecutan si el backend registra la solicitud como `APROBADA`. Si la ontología la rechaza, **la Crew se detiene después del Validador** y no gasta más llamadas al LLM.

**Protocolo de coordinación:** filtrado de axiomas + consenso ponderado.
1. A5 filtra el catálogo con HermiT y deja solo los inmuebles `InmuebleViable`.
2. A1–A3 puntúan **solo** los viables (nota 0-100 con motivo; el número lo calcula el backend, no el LLM).
3. A4 combina con `U = 0.40·precio + 0.35·zona + 0.25·vivienda` (pesos renormalizados si falta un criterio).
4. Antes de persistir, una **guardia AX5** vuelve a pasar el Top 3 por HermiT. Si un ID no existe o no es viable (posible alucinación), se rechaza con `422`.

## 3. Ontología y razonamiento efímero (Reasoning Offloading)

`ontologia/inmoia.owl` extiende la ontología del Proyecto 3 (`P3_ontologia_InmoIA.owx`, mismos IRIs): 20 clases, 11 propiedades de objeto y 15 de datos. Agrega los axiomas que en el P3 quedaron como propuesta:

| ID | Axioma | Efecto |
|---|---|---|
| AX1 | `Cliente ⊑ ∃presupuestoMaximo.decimal[> 0]` (funcional) | Presupuesto ≤ 0 → **INCONSISTENTE** |
| AX2 | `Inmueble ⊑ ∃precio.decimal[> 0]` (funcional) | Precio ≤ 0 no entra al catálogo |
| AX3 | `Casa ⊓ Departamento ⊑ ⊥` | Inmueble con dos tipos → rechazo; requisitos "casa Y departamento" → **INSATISFACIBLE** |
| AX4 | `Recomendacion ⊑ =1 recomiendaInmueble ⊓ =1 dirigidaA` | Cardinalidades del P3 |
| AX5 | `Recomendacion ⊑ ∀recomiendaInmueble.InmuebleViable` | No se persiste una recomendación inválida |

Por cada petición, `inmoia/ontologia.py` hace lo siguiente:
1. Crea un `World()` nuevo de owlready2 y carga la TBox.
2. **Materializa en RAM** las definiciones paramétricas de esa solicitud, por ejemplo `FueraDePresupuesto ≡ Inmueble ⊓ ∃precio.decimal[> 4 500 000]` e `InmuebleViable ≡ Inmueble ⊓ ¬FueraDePresupuesto ⊓ ¬HabitacionesInsuficientes ⊓ …`.
3. Afirma la ABox: cliente, requisitos, preferencias, inmuebles y recomendaciones.
4. Ejecuta HermiT: consistencia + clasificación.
5. Si hay inconsistencia, ejecuta un **diagnóstico**: relaja AX1–AX5 y las reemplaza por clases espejo `Violacion_AXn` para localizar qué individuo viola qué axioma.
6. Descarta el mundo. MongoDB guarda solo datos y resultados, nunca la ABox inferida.

Estados de validación: `APROBADA`, `SIN_VIABLES`, `INSATISFACIBLE`, `INCONSISTENTE`.

## 4. Instalación

### Requisitos
- Python 3.11–3.13
- **Java 11+** en el PATH (HermiT corre en la JVM). En Windows: instalar [Eclipse Temurin JRE](https://adoptium.net/) y comprobar con `java -version`.
- Cuenta de MongoDB Atlas (el clúster gratuito M0 basta).
- API key de Anthropic.

### Pasos (Windows PowerShell)
```powershell
git clone <url-del-repo> inmoia-mas
cd inmoia-mas
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env      # y edita .env con tus claves
python scripts/build_ontology.py   # opcional: regenera ontologia/inmoia.owl
python scripts/seed_db.py          # carga el catálogo en Atlas (validado por HermiT)
```
En macOS/Linux: `source .venv/bin/activate` y `cp .env.example .env`.

### Configurar MongoDB Atlas
1. Crea un clúster M0 en [cloud.mongodb.com](https://cloud.mongodb.com).
2. En *Database Access* crea un usuario y contraseña.
3. En *Network Access* agrega tu IP (o `0.0.0.0/0` solo para la demo).
4. En *Connect → Drivers* copia la cadena `mongodb+srv://…` en `MONGODB_URI` dentro de `.env`.

Si `MONGODB_URI` está vacío, el sistema usa una base en memoria (mongomock). Así funciona sin red, pero los datos se pierden al cerrar.

## 5. Ejecución

```bash
# Terminal 1 — backend
uvicorn inmoia.api.main:app --reload
# Documentación interactiva: http://127.0.0.1:8000/docs

# Terminal 2 — Crew
python scripts/run_crew.py --caso C01     # caso exitoso
python scripts/run_crew.py --caso R02     # rechazo semántico (casa Y departamento)
python scripts/run_crew.py --caso R01     # rechazo semántico (presupuesto negativo)
python scripts/run_crew.py --caso C01 --simulado   # respaldo sin API key

# Evaluación
python scripts/benchmark.py --n 20        # CRUD vs inferencia + tasa de éxito → results/benchmark.json
python scripts/shapley_eval.py            # φ por agente → MongoDB + results/shapley.{json,png}
```

El guion minuto a minuto de la demostración está en [`docs/guion_demo.md`](docs/guion_demo.md).

## 6. API

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/health` | Estado de API, MongoDB (ping) y ontología |
| GET/POST | `/propiedades` | Listar / crear (validado por HermiT: AX2, AX3) |
| GET/PUT/DELETE | `/propiedades/{id}` | CRUD |
| POST | `/solicitudes` | Crear solicitud con el perfil del cliente |
| POST | `/solicitudes/{id}/validar` | **A5**: validación semántica |
| POST | `/solicitudes/{id}/evaluar/{criterio}` | **A1–A3**: notas 0-100 (409 si la solicitud fue rechazada) |
| POST | `/solicitudes/{id}/consenso` | **A4**: Top 3 + guardia AX5 |
| POST | `/solicitudes/{id}/recomendaciones` | Proponer IDs concretos; HermiT los acepta o rechaza |
| GET | `/auditoria/trazas` | Trazas (filtros `solicitud_id`, `evento`) |
| GET | `/auditoria/metricas` | Tiempo promedio CRUD vs inferencia |
| POST/GET | `/auditoria/shapley` | Calcular / consultar valores de Shapley |

**Eventos de traza** (colección `trazas`): `inicio_caso`, `llamada_tool`, `evaluacion`, `validacion_recomendacion`, `recomendacion`, `paso_agente`, `fin_tarea`, `fin_caso`, `http`.

## 7. Evaluación y auditoría de Shapley

`N = {A1…A5}`. Por cada coalición `S` (32 en total) se vuelve a ejecutar la lógica de las herramientas sobre los 8 casos válidos de `data/casos_prueba.json`:

```
q_k(S) = 50·V + 30·R + 20·E          v(S) = promedio_k q_k(S)
V: fracción del Top 3 que cumple TODOS los requisitos obligatorios
R: fracción de preferencias (zona, baños, m²) que cumple la 1.ª opción
E: fracción de hechos verificables {precio, zona, vivienda, requisitos} que sustenta la explicación
```
Reglas de simulación (P2, §3.2): si falta un especialista, sus pesos se renormalizan; sin integrador, un módulo determinista ordena y `E = 0`; sin validador, se puntúa todo el catálogo; sin especialistas no hay recomendación. La parte generativa del LLM no se vuelve a ejecutar 32×8 veces. Esto es una **simplificación declarada**.

**Resultados obtenidos** (`results/`; CRUD medido con base en memoria, ver nota):

| Agente | φᵢ |
|---|---|
| A5 Validador Semántico | 27.94 |
| A2 Analista de Zona | 23.36 |
| A3 Analista de Vivienda | 20.31 |
| A1 Analista de Precio | 11.14 |
| A4 Integrador | 9.75 |
| **Σφᵢ = v(N)** | **92.50** |

Sin el Validador, `v(A1+A2+A3+A4) = 57.5` y solo el 37.5 % del Top 3 cumple los requisitos (`V = 0.375`). Con él, `V = 1.0`.

| Operación | Media |
|---|---|
| CRUD (GET/POST MongoDB en memoria) | ≈ 1 ms |
| Validación HermiT (24 inmuebles) | ≈ 620 ms |
| Consenso + guardia AX5 | ≈ 510 ms |
| Tasa de éxito (8 válidos + 3 rechazos) | 11/11 |

> Nota: los tiempos CRUD de la tabla se midieron con mongomock. Antes de presentar, corran `python scripts/benchmark.py` con Atlas configurado; los tiempos reales de red suelen estar entre 20 y 150 ms. La mayor parte del tiempo de HermiT es el arranque de la JVM.

## 8. Pruebas

```bash
pytest          # 37 pruebas: núcleo, ontología (HermiT real), API y Crew con LLM simulado
```
- `test_nucleo.py`: puntuación, consenso (pesos, renormalización, desempate, rangos) y propiedades de Shapley (aditividad, simetría, jugador nulo, eficiencia).
- `test_ontologia.py`: los viables de HermiT coinciden con un oráculo independiente en los 8 casos; AX1, AX2, AX3 y AX5.
- `test_api.py`: CRUD, rechazo 422, flujo completo, 409 cuando el validador frena, propuesta alucinada.
- `test_crew.py`: Crew real con `ScriptedLLM`. El caso válido corre las 5 tareas; el rechazo se detiene tras 2 llamadas.

## 9. Estructura

```
inmoia-mas/
├── inmoia/
│   ├── config.py          # variables de entorno, pesos
│   ├── db.py              # MongoDB Atlas (PyMongo async) / mongomock
│   ├── ontologia.py       # HermiT en RAM, diagnóstico de axiomas
│   ├── scoring.py         # notas de A1–A3
│   ├── consenso.py        # consenso ponderado
│   ├── shapley.py         # valores de Shapley exactos
│   ├── evaluacion.py      # simulación de coaliciones y métrica q
│   ├── api/               # FastAPI (main.py, schemas.py)
│   └── agents/            # crew.py, tools.py (@tool httpx), trazas.py, simulado.py
├── ontologia/             # inmoia.owl (final) y P3_ontologia_InmoIA.owx (origen)
├── data/                  # catalogo.json (sintético), casos_prueba.json
├── scripts/               # run_crew, benchmark, shapley_eval, seed_db, build_ontology
├── tests/
├── docs/                  # arquitectura, guion de la demo
└── results/               # benchmark.json, shapley.json, shapley.png, logs de la Crew
```

## 10. Limitaciones y trabajo futuro
- El catálogo es **sintético** (24 inmuebles ficticios en zonas reales de Puebla). No hay scraping ni precios reales.
- Los pesos 0.40/0.35/0.25 son iniciales y deben validarse con asesores.
- Shapley se calcula sobre coaliciones simuladas, no con 32×K ejecuciones del LLM.
- HermiT tarda ~0.5 s por la JVM. Escalarlo implicaría un servicio de razonamiento persistente.
- Líneas futuras: RAG vectorial sobre descripciones de inmuebles (Atlas Vector Search), contenedores Docker (API + razonador) y una arquitectura holónica por sector de la ciudad.

## 11. Referencias
- Russell, S., & Norvig, P. (2021). *Artificial intelligence: A modern approach* (4th ed.). Pearson.
- Shapley, L. S. (1953). A value for n-person games. En *Contributions to the Theory of Games II* (pp. 307–317). Princeton University Press.
- W3C. (2012). *OWL 2 Web Ontology Language: Structural specification and functional-style syntax* (2nd ed.). https://www.w3.org/TR/owl2-syntax/
- Glimm, B., Horrocks, I., Motik, B., Stoilos, G., & Wang, Z. (2014). HermiT: An OWL 2 reasoner. *Journal of Automated Reasoning, 53*(3), 245–269.
- Lamy, J.-B. (2017). Owlready: Ontology-oriented programming in Python with automatic classification and high level constructs for biomedical ontologies. *Artificial Intelligence in Medicine, 80*, 11–28.
- CrewAI. (s. f.). *CrewAI documentation*. https://docs.crewai.com/
- FastAPI. (s. f.). *FastAPI documentation*. https://fastapi.tiangolo.com/
- MongoDB. (s. f.). *PyMongo async driver documentation*. https://www.mongodb.com/docs/languages/python/pymongo-driver/
- Vázquez Mora, P. D. (2026). *Arquitectura y sistemas multiagentes (MAS)* [Material de clase]. Universidad Iberoamericana Puebla.
