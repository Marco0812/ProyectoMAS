# Guion de la demostración en vivo (5 min)

**Antes de entrar:** abran 3 terminales y el navegador. Tengan ya hecho `seed_db.py` y `shapley_eval.py`, con `results/shapley.png` abierto en otra pestaña.

## Minuto 1 — Entorno y servicios
```bash
uvicorn inmoia.api.main:app          # terminal 1: muestra que arranca
```
Abrir `http://127.0.0.1:8000/health` y señalar tres cosas:
- `mongo.ok: true · backend: atlas · latencia_ms`
- `ontologia`: 20 clases, axiomas AX1–AX5
- `propiedades: 24`

Opcional: mostrar en el navegador de Atlas la colección `propiedades`.

## Minuto 2 — Caso 1: resolución exitosa
```bash
python scripts/run_crew.py --caso C01   # familia, casa, ≤ $4.5 M, Angelópolis
```
Mientras corre, señalar en el log de CrewAI:
1. A5 llama `Validar solicitud con la ontologia` → `APROBADA`, 7 viables. P01 queda excluido: "precio mayor al presupuesto".
2. A1/A2/A3 llaman `Evaluar criterio inmobiliario`.
3. A4 llama `Consenso inmobiliario`: Top 3 = P22, P15, P17 con aportes por criterio; la verificación AX5 da APROBADA.

Al final, en Atlas o en `/solicitudes/{id}/recomendacion`, mostrar que la recomendación se guardó.

## Minuto 3 — Caso 2: detección y rechazo semántico
```bash
python scripts/run_crew.py --caso R02   # requisitos: casa Y departamento
```
- HermiT detecta que `InmuebleViable` es insatisfacible por **AX3: Casa ⊓ Departamento ⊑ ⊥**.
- El Validador reporta `INSATISFACIBLE` con su justificación y **las otras 4 tareas se omiten** ("Skipping conditional task").

Si sobra tiempo, `--caso R01` (presupuesto negativo → AX1). También pueden mostrar en `/docs` un `POST /solicitudes/{id}/recomendaciones` con `["P01"]` para la solicitud del caso 1: **422, AX5** (guardia contra alucinaciones).

## Minutos 4–5 — Trazas y Shapley
- `http://127.0.0.1:8000/auditoria/trazas?solicitud_id=<id caso 1>`: eventos `inicio_caso → llamada_tool → evaluacion → recomendacion → fin_tarea`.
- `http://127.0.0.1:8000/auditoria/metricas`: CRUD (ms) vs inferencia (~600 ms).
- `GET /auditoria/shapley` y la gráfica `results/shapley.png`: el Validador tiene el φ más alto (27.9); Σφ = v(N) = 92.5 (eficiencia).

## Plan B
- Si falla la API key o la red del LLM: `--simulado` (misma Crew, herramientas y trazas; el LLM es determinista).
- Si falla Atlas: dejen `MONGODB_URI` vacío y reinicien uvicorn (base en memoria).
