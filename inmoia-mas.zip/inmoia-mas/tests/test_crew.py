"""Prueba de integración de la Crew (CrewAI + @tool httpx + API real) con LLM simulado."""
import httpx

from inmoia.agents.crew import crear_crew
from inmoia.agents.simulado import ScriptedLLM
from inmoia.agents.tools import evaluar_criterio_tool


def _crear(url, perfil):
    return httpx.post(f"{url}/solicitudes", json={"perfil": perfil}).json()["id"]


def test_crew_resuelve_caso_valido(servidor, datos):
    perfil = datos[2]["validos"][1]["perfil"]
    sid = _crear(servidor, perfil)
    llm = ScriptedLLM()
    crear_crew(sid, llm=llm).kickoff()
    assert httpx.get(f"{servidor}/solicitudes/{sid}").json()["estado"] == "RECOMENDADA"
    rec = httpx.get(f"{servidor}/solicitudes/{sid}/recomendacion").json()
    assert len(rec["top3"]) == 3 and rec["validacion_ax5"] == "APROBADA"
    trazas = httpx.get(f"{servidor}/auditoria/trazas", params={"solicitud_id": sid}).json()
    assert sum(t["evento"] == "fin_tarea" for t in trazas) == 5


def test_crew_se_detiene_ante_rechazo_semantico(servidor, datos):
    caso = datos[2]["rechazo"][1]   # casa Y departamento
    sid = _crear(servidor, caso["perfil"])
    llm = ScriptedLLM()
    crear_crew(sid, llm=llm).kickoff()
    assert httpx.get(f"{servidor}/solicitudes/{sid}").json()["estado"] == "INSATISFACIBLE"
    assert llm.llamadas == 2          # solo el Validador trabajó; el resto se omitió
    assert httpx.get(f"{servidor}/solicitudes/{sid}/recomendacion").status_code == 404


def test_tool_rechaza_criterio_invalido(servidor):
    salida = evaluar_criterio_tool.run(solicitud_id="S0", criterio="color")
    assert "criterio inválido" in salida
