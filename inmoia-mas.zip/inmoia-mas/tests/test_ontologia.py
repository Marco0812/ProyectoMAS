"""Pruebas de la validación semántica con HermiT (requiere Java)."""
import pytest

from inmoia import ontologia
from inmoia.evaluacion import cumple_requisitos


def test_casos_validos_coinciden_con_oraculo(datos):
    """Los viables que infiere HermiT == los que calcula un oráculo independiente."""
    inmuebles, _, casos = datos
    for caso in casos["validos"]:
        r = ontologia.validar_solicitud(caso["perfil"], inmuebles, solicitud_id=caso["id"])
        esperado = sorted(i["id"] for i in inmuebles if cumple_requisitos(i, caso["perfil"]))
        assert r["estado"] == "APROBADA", caso["id"]
        assert sorted(r["viables"]) == esperado, caso["id"]


@pytest.mark.parametrize("idx", [0, 1, 2])
def test_casos_de_rechazo(datos, idx):
    inmuebles, _, casos = datos
    caso = casos["rechazo"][idx]
    r = ontologia.validar_solicitud(caso["perfil"], inmuebles, solicitud_id=caso["id"])
    assert r["estado"] == caso["esperado"]


def test_presupuesto_negativo_viola_ax1(datos):
    inmuebles, _, casos = datos
    r = ontologia.validar_solicitud(casos["rechazo"][0]["perfil"], inmuebles[:3])
    assert [v["axioma"] for v in r["violaciones"]] == ["AX1"]


def test_recomendacion_fuera_de_presupuesto_viola_ax5(datos):
    inmuebles, _, casos = datos
    perfil = casos["validos"][0]["perfil"]          # máx 4.5 M
    por_id = {i["id"]: i for i in inmuebles}
    r = ontologia.validar_solicitud(perfil, [por_id["P22"], por_id["P01"]], ["P22", "P01"])
    assert r["estado"] == "INCONSISTENTE"
    v = r["violaciones"][0]
    assert v["axioma"] == "AX5" and v["inmueble"] == "P01"
    assert "precio mayor al presupuesto máximo" in v["motivos"]


def test_recomendacion_valida_es_consistente(datos):
    inmuebles, _, casos = datos
    perfil = casos["validos"][0]["perfil"]
    p22 = next(i for i in inmuebles if i["id"] == "P22")
    assert ontologia.validar_solicitud(perfil, [p22], ["P22"])["estado"] == "APROBADA"


def test_inmueble_casa_y_departamento_viola_ax3():
    r = ontologia.validar_inmueble({"id": "PX", "tipo": "casa", "tipos": ["casa", "departamento"],
                                    "precio": 2e6, "habitaciones": 2, "zona": "La Paz"})
    assert r["estado"] == "INCONSISTENTE" and r["violaciones"][0]["axioma"] == "AX3"


def test_inmueble_precio_cero_viola_ax2():
    r = ontologia.validar_inmueble({"id": "PZ", "tipo": "casa", "precio": 0,
                                    "habitaciones": 2, "zona": "La Paz"})
    assert r["violaciones"][0]["axioma"] == "AX2"


def test_catalogo_completo_es_consistente(datos):
    assert ontologia.validar_inmueble(datos[0])["estado"] == "VALIDO"
