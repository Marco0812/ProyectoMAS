import os
import socket
import sys
import threading
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["MONGODB_URI"] = ""  # las pruebas siempre usan la base en memoria
os.environ.setdefault("CREWAI_DISABLE_TELEMETRY", "true")
os.environ.setdefault("CREWAI_TRACING_ENABLED", "false")
os.environ.setdefault("OTEL_SDK_DISABLED", "true")

from inmoia import config, db  # noqa: E402

config.DB_BACKEND = "memoria"


@pytest.fixture
def client():
    from fastapi.testclient import TestClient

    from inmoia.api.main import app
    db.reset_db_for_tests()
    with TestClient(app) as c:
        yield c


@pytest.fixture(scope="module")
def servidor():
    """Levanta uvicorn en un hilo para probar las @tool (httpx real)."""
    import uvicorn

    from inmoia.api.main import app
    db.reset_db_for_tests()
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        puerto = s.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=puerto, log_level="warning"))
    hilo = threading.Thread(target=server.run, daemon=True)
    hilo.start()
    while not server.started:
        time.sleep(0.05)
    url_anterior = config.API_URL
    config.API_URL = f"http://127.0.0.1:{puerto}"
    yield config.API_URL
    config.API_URL = url_anterior
    server.should_exit = True
    hilo.join(timeout=5)


@pytest.fixture(scope="session")
def datos():
    from inmoia.evaluacion import cargar_datos
    return cargar_datos()
