"""Pruebas de la lógica pura: puntuación, consenso y Shapley."""
import pytest

from inmoia.consenso import consenso_ponderado
from inmoia.scoring import puntuar_precio, puntuar_vivienda, puntuar_zona
from inmoia.shapley import valores_shapley

PERFIL = {"max_precio": 4_000_000, "min_habs": 3, "zonas_preferidas": ["La Paz"],
          "banos_deseados": 2, "m2_deseados": 150, "requiere_estacionamiento": True}
SECTORES = {"La Paz": "Centro", "Huexotitla": "Centro", "Momoxpan": "Norte"}


def inm(**kw):
    base = {"id": "X", "precio": 3_000_000, "habitaciones": 3, "banos": 2,
            "metros_cuadrados": 150, "estacionamiento": True, "zona": "La Paz"}
    return {**base, **kw}


# ---------- scoring ----------
def test_precio_dentro_supera_a_fuera_de_presupuesto():
    dentro, _ = puntuar_precio(inm(precio=3_900_000), PERFIL)
    fuera, motivo = puntuar_precio(inm(precio=4_200_000), PERFIL)
    assert 60 <= dentro <= 100 and fuera < dentro
    assert "excede" in motivo


def test_precio_con_presupuesto_invalido_es_cero():
    assert puntuar_precio(inm(), {"max_precio": -1})[0] == 0


@pytest.mark.parametrize("zona,esperado", [("La Paz", 100), ("Huexotitla", 60), ("Momoxpan", 20)])
def test_zona_por_niveles(zona, esperado):
    assert puntuar_zona(inm(zona=zona), PERFIL, SECTORES)[0] == esperado


def test_vivienda_completa_vale_100_y_sin_estacionamiento_obligatorio_baja():
    assert puntuar_vivienda(inm(), PERFIL)[0] == 100
    assert puntuar_vivienda(inm(estacionamiento=False), PERFIL)[0] == 80


# ---------- consenso ----------
def test_consenso_pondera_y_ordena():
    evals = {"precio": {"A": 100, "B": 50}, "zona": {"A": 0, "B": 100}, "vivienda": {"A": 50, "B": 50}}
    top = consenso_ponderado(evals)
    # A = 40 + 0 + 12.5 = 52.5 ; B = 20 + 35 + 12.5 = 67.5
    assert [r["id"] for r in top] == ["B", "A"]
    assert top[0]["puntaje"] == 67.5
    assert top[0]["aportes"] == {"precio": 20.0, "zona": 35.0, "vivienda": 12.5}


def test_consenso_renormaliza_si_falta_un_especialista():
    top = consenso_ponderado({"precio": {"A": 100}, "zona": {"A": 100}})
    assert top[0]["puntaje"] == 100.0


def test_consenso_desempata_por_id_y_limita_top3():
    evals = {"precio": {k: 80 for k in "DCBA"}}
    assert [r["id"] for r in consenso_ponderado(evals)] == ["A", "B", "C"]


@pytest.mark.parametrize("nota", [101, -1, "90", True])
def test_consenso_rechaza_notas_invalidas(nota):
    with pytest.raises(ValueError):
        consenso_ponderado({"precio": {"A": nota}})


def test_consenso_sin_evaluaciones_devuelve_vacio():
    assert consenso_ponderado({}) == []


# ---------- Shapley ----------
def test_shapley_juego_aditivo_devuelve_valores_individuales():
    pesos = {"a": 10, "b": 20, "c": 5}
    phi = valores_shapley(list(pesos), lambda s: sum(pesos[i] for i in s))
    assert phi == pytest.approx(pesos)


def test_shapley_simetria_eficiencia_y_jugador_nulo():
    # v = 60 si están a y b juntos; c es nulo
    v = lambda s: 60.0 if {"a", "b"} <= s else 0.0  # noqa: E731
    phi = valores_shapley(["a", "b", "c"], v)
    assert phi["a"] == pytest.approx(30) and phi["b"] == pytest.approx(30)
    assert phi["c"] == pytest.approx(0)
    assert sum(phi.values()) == pytest.approx(60)
