"""Pruebas del backend FastAPI (MongoDB en memoria + HermiT real)."""

PERFIL_OK = {"max_precio": 4_500_000, "min_habs": 3, "tipos_requeridos": ["casa"],
             "requiere_estacionamiento": True,
             "zonas_preferidas": ["Lomas de Angelópolis", "Angelópolis"],
             "banos_deseados": 3, "m2_deseados": 200}


def nueva(client, perfil):
    return client.post("/solicitudes", json={"perfil": perfil}).json()["id"]


def test_health_reporta_servicios(client):
    h = client.get("/health").json()
    assert h["api"] == "ok" and h["mongo"]["ok"] and h["propiedades"] == 24
    assert h["ontologia"]["axiomas_duros"] == ["AX1", "AX2", "AX3", "AX4", "AX5"]


def test_crud_propiedades(client):
    nueva_p = {"id": "P99", "tipo": "casa", "precio": 2_000_000, "habitaciones": 2,
               "zona": "La Paz", "estacionamiento": True}
    assert client.post("/propiedades", json=nueva_p).status_code == 201
    assert client.get("/propiedades/P99").json()["precio"] == 2_000_000
    assert client.post("/propiedades", json=nueva_p).status_code == 409
    nueva_p["precio"] = 2_100_000
    assert client.put("/propiedades/P99", json=nueva_p).status_code == 200
    assert client.delete("/propiedades/P99").status_code == 200
    assert client.get("/propiedades/P99").status_code == 404


def test_post_propiedad_inconsistente_rechazada(client):
    r = client.post("/propiedades", json={"id": "PX", "tipo": "casa", "tipos": ["casa", "departamento"],
                                          "precio": 2e6, "habitaciones": 2, "zona": "La Paz"})
    assert r.status_code == 422
    assert r.json()["detail"]["violaciones"][0]["axioma"] == "AX3"
    assert client.get("/propiedades/PX").status_code == 404


def test_flujo_completo_recomienda_y_audita(client):
    sid = nueva(client, PERFIL_OK)
    assert client.post(f"/solicitudes/{sid}/validar").json()["estado"] == "APROBADA"
    for c in ("precio", "zona", "vivienda"):
        assert client.post(f"/solicitudes/{sid}/evaluar/{c}").status_code == 200
    r = client.post(f"/solicitudes/{sid}/consenso").json()
    assert r["top3"][0]["id"] == "P22" and r["validacion_ax5"] == "APROBADA"
    eventos = {t["evento"] for t in client.get("/auditoria/trazas", params={"solicitud_id": sid}).json()}
    assert {"inicio_caso", "llamada_tool", "evaluacion", "recomendacion"} <= eventos


def test_validador_frena_la_operacion(client):
    sid = nueva(client, {**PERFIL_OK, "tipos_requeridos": ["casa", "departamento"]})
    assert client.post(f"/solicitudes/{sid}/validar").json()["estado"] == "INSATISFACIBLE"
    r = client.post(f"/solicitudes/{sid}/evaluar/precio")
    assert r.status_code == 409 and "frenada" in r.json()["detail"]["mensaje"]


def test_consenso_exige_todas_las_evaluaciones(client):
    sid = nueva(client, PERFIL_OK)
    client.post(f"/solicitudes/{sid}/validar")
    client.post(f"/solicitudes/{sid}/evaluar/precio")
    r = client.post(f"/solicitudes/{sid}/consenso")
    assert r.status_code == 409 and set(r.json()["detail"]["faltan"]) == {"zona", "vivienda"}


def test_propuesta_alucinada_o_invalida_rechazada(client):
    sid = nueva(client, PERFIL_OK)
    r = client.post(f"/solicitudes/{sid}/recomendaciones", json={"ids": ["P01"]})
    assert r.status_code == 422 and r.json()["detail"]["violaciones"][0]["axioma"] == "AX5"
    r = client.post(f"/solicitudes/{sid}/recomendaciones", json={"ids": ["P777"]})
    assert r.status_code == 422 and r.json()["detail"]["ids"] == ["P777"]


def test_metricas_separan_crud_e_inferencia(client):
    sid = nueva(client, PERFIL_OK)
    client.get("/propiedades")
    client.post(f"/solicitudes/{sid}/validar")
    m = client.get("/auditoria/metricas").json()
    assert "crud" in m and "inferencia" in m
