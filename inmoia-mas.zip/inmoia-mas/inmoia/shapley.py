"""Valores de Shapley exactos (Shapley, 1953) en Python puro.

φ_i = Σ_{S ⊆ N\\{i}} |S|!(n-|S|-1)!/n! · [v(S ∪ {i}) - v(S)]
"""
from __future__ import annotations

from itertools import combinations
from math import factorial
from typing import Callable, Hashable, Iterable


def coaliciones(jugadores: Iterable[Hashable]):
    js = list(jugadores)
    for k in range(len(js) + 1):
        for combo in combinations(js, k):
            yield frozenset(combo)


def valores_shapley(jugadores: list[Hashable], v: Callable[[frozenset], float]) -> dict:
    n = len(jugadores)
    cache: dict[frozenset, float] = {}

    def val(s: frozenset) -> float:
        if s not in cache:
            cache[s] = 0.0 if not s else float(v(s))
        return cache[s]

    phi = {}
    for i in jugadores:
        resto = [j for j in jugadores if j != i]
        total = 0.0
        for s in coaliciones(resto):
            peso = factorial(len(s)) * factorial(n - len(s) - 1) / factorial(n)
            total += peso * (val(s | {i}) - val(s))
        phi[i] = total
    return phi
