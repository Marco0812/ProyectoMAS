"""LLM simulado (determinista): prueba el cableado de la Crew sin API key
(pruebas unitarias y respaldo de la demo con --simulado).

Responde en formato ReAct: primero pide su herramienta, luego entrega la
respuesta final con la observación recibida. No sustituye al LLM real en la
demo; solo verifica que agentes, herramientas, condiciones y trazas funcionan.
"""
import re

from crewai.llms.base_llm import BaseLLM

HERRAMIENTA = {
    "Validador": ("Validar solicitud con la ontologia", None),
    "Precio": ("Evaluar criterio inmobiliario", "precio"),
    "Zona": ("Evaluar criterio inmobiliario", "zona"),
    "Vivienda": ("Evaluar criterio inmobiliario", "vivienda"),
    "Integrador": ("Consenso inmobiliario", None),
}


class ScriptedLLM(BaseLLM):
    def __init__(self, **kw):
        super().__init__(model="scripted-llm", **kw)
        self.llamadas = 0

    def supports_function_calling(self) -> bool:
        return False

    def call(self, messages, tools=None, callbacks=None, available_functions=None,
             from_task=None, from_agent=None, response_model=None):
        self.llamadas += 1
        texto = messages if isinstance(messages, str) else "\n".join(
            str(m.get("content", "")) for m in messages)
        asistente = [] if isinstance(messages, str) else [
            str(m.get("content", "")) for m in messages if m.get("role") == "assistant"]
        if asistente:  # ya se ejecutó la herramienta: la observación está en el último turno
            obs = asistente[-1].rsplit("Observation:", 1)[-1].strip()[:800]
            return f"Thought: Ya tengo el resultado de la herramienta.\nFinal Answer: {obs}"
        rol = getattr(from_agent, "role", "")
        nombre, criterio = next((v for k, v in HERRAMIENTA.items() if k in rol), (None, None))
        if nombre is None:
            return "Thought: listo.\nFinal Answer: sin acción"
        sid = re.search(r"solicitud (S[0-9a-f]{8})", texto).group(1)
        args = f'{{"solicitud_id": "{sid}"' + (f', "criterio": "{criterio}"}}' if criterio else "}")
        return f"Thought: Debo usar mi herramienta.\nAction: {nombre}\nAction Input: {args}"
