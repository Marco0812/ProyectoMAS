"""Definición de la Crew de InmoIA (CrewAI, Process.sequential).

Orden:  T0 A5 Validador → T1 A1 Precio → T2 A2 Zona → T3 A3 Vivienda → T4 A4 Integrador
T1-T4 son ConditionalTask: solo se ejecutan si el backend registra que la
solicitud fue APROBADA por la ontología. Así el Validador frena la operación.
"""
from __future__ import annotations

import time

import httpx
from crewai import LLM, Agent, Crew, Process, Task
from crewai.tasks.conditional_task import ConditionalTask

from .. import config
from .tools import consenso_tool, evaluar_criterio_tool, validar_solicitud_tool
from .trazas import CapturadorTrazas

REGLA = ("Usa SIEMPRE tu herramienta; no inventes precios, zonas, IDs ni puntuaciones. "
         "Si la herramienta devuelve un error, repórtalo tal cual.")


def _llm(llm=None):
    return llm or LLM(model=config.LLM_MODEL, temperature=0)


def crear_agentes(llm=None) -> dict[str, Agent]:
    m = _llm(llm)
    comun = dict(llm=m, verbose=True, allow_delegation=False, max_iter=4)
    return {
        "A5": Agent(role="A5. Validador Semántico",
                    goal="Verificar con la ontología OWL 2 y HermiT que la solicitud sea consistente "
                         "y detener la operación con justificación lógica si viola un axioma.",
                    backstory="Ingeniero de conocimiento. Confía en el razonador, no en suposiciones. "
                              + REGLA, tools=[validar_solicitud_tool], **comun),
        "A1": Agent(role="A1. Analista de Precio",
                    goal="Revisar la viabilidad económica de las viviendas y asignar una nota de 0 a 100.",
                    backstory="Asesor con experiencia comparando precios y presupuestos familiares. " + REGLA,
                    tools=[evaluar_criterio_tool], **comun),
        "A2": Agent(role="A2. Analista de Zona",
                    goal="Valorar qué tanto coincide la ubicación con las zonas elegidas por el usuario.",
                    backstory="Conoce las zonas de Puebla y nunca inventa distancias. " + REGLA,
                    tools=[evaluar_criterio_tool], **comun),
        "A3": Agent(role="A3. Analista de Vivienda",
                    goal="Evaluar habitaciones, baños, metros cuadrados y estacionamiento.",
                    backstory="Especialista en comparar características de casas y departamentos. " + REGLA,
                    tools=[evaluar_criterio_tool], **comun),
        "A4": Agent(role="A4. Integrador de Recomendaciones",
                    goal="Combinar las evaluaciones con la herramienta de consenso y explicar el top 3.",
                    backstory="Asistente inmobiliario que explica decisiones de forma clara y neutral, "
                              "citando solo los motivos que devuelve la herramienta. " + REGLA,
                    tools=[consenso_tool], **comun),
    }


def solicitud_aprobada(solicitud_id: str) -> bool:
    try:
        r = httpx.get(f"{config.API_URL}/solicitudes/{solicitud_id}", timeout=10)
        return r.json().get("estado") in ("APROBADA", "EVALUANDO", "RECOMENDADA")
    except httpx.HTTPError:
        return False


def crear_crew(solicitud_id: str, llm=None, run_id: str | None = None) -> Crew:
    ag = crear_agentes(llm)
    cond = lambda _salida: solicitud_aprobada(solicitud_id)  # noqa: E731

    t0 = Task(description=f"Valida la solicitud {solicitud_id} con la herramienta de ontología. "
                          "Informa el estado, cuántos inmuebles son viables y, si el estado no es "
                          "APROBADA, cita cada axioma violado y el individuo que lo viola.",
              expected_output="Veredicto: APROBADA o RECHAZADA, con estado de HermiT y justificación lógica.",
              agent=ag["A5"])
    especialistas = []
    for aid, criterio in (("A1", "precio"), ("A2", "zona"), ("A3", "vivienda")):
        especialistas.append(ConditionalTask(
            description=f"Evalúa el criterio '{criterio}' para la solicitud {solicitud_id} "
                        "usando tu herramienta. Resume las 3 mejores notas con su ID y motivo.",
            expected_output="Lista breve: ID, puntuación 0-100 y motivo.",
            agent=ag[aid], condition=cond))
    t4 = ConditionalTask(
        description=f"Ejecuta el consenso inmobiliario para la solicitud {solicitud_id}. "
                    "Con el top 3 devuelto, explica al cliente en español por qué la primera opción "
                    "supera a las demás, citando aportes por criterio y motivos. Indica que la "
                    "recomendación fue verificada por la ontología (AX5).",
        expected_output="Top 3 (ID y puntaje) y una explicación de 120-180 palabras.",
        agent=ag["A4"], condition=cond, context=especialistas)

    capt = CapturadorTrazas(solicitud_id, run_id or solicitud_id)
    return Crew(agents=list(ag.values()), tasks=[t0, *especialistas, t4],
                process=Process.sequential, verbose=True,
                task_callback=capt.fin_tarea, step_callback=capt.paso,
                output_log_file=str(config.RESULTS_DIR / f"crew_{solicitud_id}_{int(time.time())}.log"))
