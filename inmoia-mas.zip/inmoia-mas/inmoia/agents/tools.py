"""Custom Tools (@tool) que conectan la Crew con la API asíncrona vía httpx.

Cada herramienta es un adaptador delgado: valida argumentos, llama un
endpoint y devuelve JSON en texto. Los números siempre vienen del backend,
nunca del LLM.
"""
from __future__ import annotations

import json

import httpx
from crewai.tools import tool

from .. import config

_TIMEOUT = httpx.Timeout(60.0, connect=5.0)


def _post(ruta: str, payload: dict | None = None) -> str:
    """POST al backend. Los errores HTTP se devuelven como JSON para que el
    agente los lea y los justifique, en lugar de reventar la ejecución."""
    try:
        with httpx.Client(base_url=config.API_URL, timeout=_TIMEOUT) as cliente:
            r = cliente.post(ruta, json=payload)
        cuerpo = r.json()
        if r.is_error:
            return json.dumps({"error_http": r.status_code, "detalle": cuerpo.get("detail", cuerpo)},
                              ensure_ascii=False)
        return json.dumps(cuerpo, ensure_ascii=False)
    except httpx.HTTPError as exc:
        return json.dumps({"error_conexion": str(exc), "api": config.API_URL}, ensure_ascii=False)


@tool("Validar solicitud con la ontologia")
def validar_solicitud_tool(solicitud_id: str) -> str:
    """Valida la solicitud contra la ontología OWL 2 con el razonador HermiT.
    Devuelve el estado (APROBADA, SIN_VIABLES, INSATISFACIBLE o INCONSISTENTE),
    los inmuebles viables, los excluidos con su motivo y los axiomas violados."""
    return _post(f"/solicitudes/{solicitud_id.strip()}/validar")


@tool("Evaluar criterio inmobiliario")
def evaluar_criterio_tool(solicitud_id: str, criterio: str) -> str:
    """Calcula en el backend la nota 0-100 de cada inmueble viable para un criterio.
    criterio debe ser exactamente 'precio', 'zona' o 'vivienda'."""
    criterio = criterio.strip().lower()
    if criterio not in config.CRITERIOS:
        return json.dumps({"error": f"criterio inválido, use uno de {config.CRITERIOS}"}, ensure_ascii=False)
    return _post(f"/solicitudes/{solicitud_id.strip()}/evaluar/{criterio}")


@tool("Consenso inmobiliario")
def consenso_tool(solicitud_id: str) -> str:
    """Combina las tres evaluaciones con el consenso ponderado
    U = 0.40·precio + 0.35·zona + 0.25·vivienda y devuelve el top 3 con aportes
    y motivos. Antes de guardar, HermiT verifica el axioma AX5."""
    return _post(f"/solicitudes/{solicitud_id.strip()}/consenso")
