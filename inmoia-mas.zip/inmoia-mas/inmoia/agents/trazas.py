"""Capturador de trazas de CrewAI → POST /auditoria/trazas (MongoDB).

Complementa las trazas que el backend registra por sí mismo: aquí se guarda
lo que solo CrewAI conoce (qué agente terminó qué tarea y cuánto tardó).
"""
from __future__ import annotations

import time

import httpx

from .. import config

_ROL_A_ID = {"Validador": "A5", "Precio": "A1", "Zona": "A2", "Vivienda": "A3", "Integrador": "A4"}


def _agent_id(rol: str | None) -> str | None:
    for clave, aid in _ROL_A_ID.items():
        if rol and clave in rol:
            return aid
    return None


class CapturadorTrazas:
    def __init__(self, solicitud_id: str, run_id: str):
        self.solicitud_id = solicitud_id
        self.run_id = run_id
        self._t = time.perf_counter()
        self.pasos = 0

    def _enviar(self, evento: str, agent_id=None, **datos):
        try:
            httpx.post(f"{config.API_URL}/auditoria/trazas", timeout=5, json={
                "evento": evento, "solicitud_id": self.solicitud_id, "run_id": self.run_id,
                "agent_id": agent_id, "datos": datos})
        except httpx.HTTPError:
            pass  # la auditoría nunca debe tumbar la ejecución

    def paso(self, paso):
        self.pasos += 1
        herramienta = getattr(paso, "tool", None)
        if herramienta:
            self._enviar("paso_agente", herramienta=str(herramienta),
                         entrada=str(getattr(paso, "tool_input", ""))[:300])

    def fin_tarea(self, salida):
        ahora = time.perf_counter()
        dur = round((ahora - self._t) * 1000, 1)
        self._t = ahora
        self._enviar("fin_tarea", _agent_id(getattr(salida, "agent", None)),
                     task=str(getattr(salida, "description", ""))[:120],
                     estado="completada", duracion_ms=dur,
                     resumen=str(getattr(salida, "raw", ""))[:500])
