"""Capa de persistencia: MongoDB Atlas (PyMongo async) o mongomock en memoria.

Ambos backends exponen la misma interfaz asíncrona mínima, así el backend
FastAPI no sabe cuál está usando. Colecciones:
  propiedades, solicitudes, evaluaciones, recomendaciones, trazas, shapley
"""
from __future__ import annotations

import time
from typing import Any

from . import config

COLECCIONES = ("propiedades", "solicitudes", "evaluaciones",
               "recomendaciones", "trazas", "shapley")


# ---------- Adaptador en memoria (mongomock) ----------
class _MemCursor:
    def __init__(self, cursor):
        self._cursor = cursor

    def sort(self, *args, **kwargs):
        self._cursor = self._cursor.sort(*args, **kwargs)
        return self

    def limit(self, n: int):
        self._cursor = self._cursor.limit(n)
        return self

    async def to_list(self, length: int | None = None):
        docs = list(self._cursor)
        return docs if length is None else docs[:length]


class _MemCollection:
    def __init__(self, coll):
        self._c = coll

    def find(self, *args, **kwargs):
        return _MemCursor(self._c.find(*args, **kwargs))

    def __getattr__(self, name):  # insert_one, find_one, update_one, ...
        fn = getattr(self._c, name)

        async def _async(*args, **kwargs):
            return fn(*args, **kwargs)
        return _async


class _MemDatabase:
    def __init__(self):
        import mongomock
        self._db = mongomock.MongoClient()[config.MONGODB_DB]

    def __getitem__(self, name: str) -> _MemCollection:
        return _MemCollection(self._db[name])

    async def command(self, cmd: str):
        return {"ok": 1.0}


_db: Any = None


def get_db():
    """Devuelve una única instancia de base de datos por proceso."""
    global _db
    if _db is None:
        if config.DB_BACKEND == "atlas":
            from pymongo import AsyncMongoClient
            client = AsyncMongoClient(config.MONGODB_URI, serverSelectionTimeoutMS=8000,
                                      appname="InmoIA-MAS")
            _db = client[config.MONGODB_DB]
        else:
            _db = _MemDatabase()
    return _db


def reset_db_for_tests():
    """Solo pruebas: fuerza una base en memoria nueva."""
    global _db
    _db = _MemDatabase()
    return _db


async def ping() -> dict:
    db = get_db()
    t0 = time.perf_counter()
    try:
        await db.command("ping")
        return {"ok": True, "backend": config.DB_BACKEND,
                "latencia_ms": round((time.perf_counter() - t0) * 1000, 2)}
    except Exception as exc:  # pragma: no cover - depende de la red
        return {"ok": False, "backend": config.DB_BACKEND, "error": str(exc)}


async def crear_indices():
    db = get_db()
    await db["propiedades"].create_index("id", unique=True)
    await db["solicitudes"].create_index("id", unique=True)
    await db["trazas"].create_index([("solicitud_id", 1), ("ts", 1)])
