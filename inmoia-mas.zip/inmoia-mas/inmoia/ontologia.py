"""Validación semántica con HermiT en RAM (Reasoning Offloading).

Por cada petición se crea un `World` de owlready2 nuevo y efímero:
  1. se carga la TBox (ontologia/inmoia.owl),
  2. se materializan en RAM las definiciones paramétricas de la solicitud
     (p. ej. FueraDePresupuesto ≡ Inmueble ⊓ ∃precio.decimal[> 4 500 000]),
  3. se afirma la ABox (cliente, inmuebles candidatos y, si existen,
     recomendaciones propuestas),
  4. HermiT comprueba consistencia y clasifica individuos,
  5. el mundo se descarta. MongoDB nunca guarda inferencias: solo datos.

Si la ontología resulta inconsistente se ejecuta un diagnóstico: se relajan
los axiomas duros (AX1-AX5) y se sustituyen por "clases espejo" de violación
para que HermiT diga exactamente qué individuo rompe qué axioma.
"""
from __future__ import annotations

import threading
import time
import types
import uuid
from functools import lru_cache

from owlready2 import (ConstrainedDatatype, Not, OwlReadyInconsistentOntologyError,
                       Restriction, Thing, World, sync_reasoner_hermit)

from . import config

NS = "https://example.org/inmoia/ontologia#"
_LOCK = threading.Lock()  # owlready2/HermiT no son thread-safe

AXIOMAS = {
    "AX1": "Cliente ⊑ ∃presupuestoMaximo.decimal[> 0] (todo cliente declara un presupuesto positivo)",
    "AX2": "Inmueble ⊑ ∃precio.decimal[> 0] (todo inmueble tiene precio positivo)",
    "AX3": "Casa ⊓ Departamento ⊑ ⊥ (un inmueble no puede ser casa y departamento a la vez)",
    "AX4": "Recomendacion ⊑ =1 recomiendaInmueble ⊓ =1 dirigidaA",
    "AX5": "Recomendacion ⊑ ∀recomiendaInmueble.InmuebleViable (solo se recomiendan inmuebles viables)",
}

# Clases paramétricas (declaradas en la TBox, definidas en RAM por solicitud)
REQUISITOS = {
    "FueraDePresupuesto": "precio mayor al presupuesto máximo",
    "HabitacionesInsuficientes": "menos habitaciones que el mínimo requerido",
    "TipoNoSolicitado": "tipo de inmueble distinto al requerido",
    "SinEstacionamientoRequerido": "no tiene estacionamiento y es obligatorio",
}


class _Ctx:
    """Mundo efímero con accesos cortos a clases y propiedades."""

    def __init__(self):
        self.world = World()
        self.base = self.world.get_ontology(config.ONTOLOGY_PATH.as_uri()).load()
        self.eph = self.world.get_ontology(f"http://inmoia.local/efimera/{uuid.uuid4().hex}#")

    def __getattr__(self, nombre):
        ent = self.world[NS + nombre]
        if ent is None:
            raise AttributeError(nombre)
        return ent


# ---------------------------------------------------------------- TBox efímera
def _definir_requisitos(ctx: _Ctx, perfil: dict) -> list[str]:
    """Materializa las definiciones paramétricas de la solicitud. Devuelve las usadas."""
    usadas = []
    with ctx.base:
        ctx.FueraDePresupuesto.equivalent_to.append(
            ctx.Inmueble & ctx.precio.some(
                ConstrainedDatatype(float, min_exclusive=float(perfil["max_precio"]))))
        usadas.append("FueraDePresupuesto")

        if int(perfil.get("min_habs", 0)) > 0:
            ctx.HabitacionesInsuficientes.equivalent_to.append(
                ctx.Inmueble & ctx.habitaciones.some(
                    ConstrainedDatatype(int, max_exclusive=int(perfil["min_habs"]))))
            usadas.append("HabitacionesInsuficientes")

        tipos = [t.lower() for t in perfil.get("tipos_requeridos") or []]
        if tipos:
            clases = [_clase_tipo(ctx, t) for t in tipos]
            requerido = clases[0]
            for c in clases[1:]:
                requerido = requerido & c  # cada tipo listado es obligatorio (conjunción)
            ctx.TipoNoSolicitado.equivalent_to.append(ctx.Inmueble & Not(requerido))
            usadas.append("TipoNoSolicitado")

        if perfil.get("requiere_estacionamiento"):
            ctx.SinEstacionamientoRequerido.equivalent_to.append(
                ctx.Inmueble & ctx.estacionamiento.value(False))
            usadas.append("SinEstacionamientoRequerido")

        viable = ctx.Inmueble
        for nombre in usadas:
            viable = viable & Not(getattr(ctx, nombre))
        ctx.InmuebleViable.equivalent_to.append(viable)
    return usadas


def _clase_tipo(ctx: _Ctx, tipo: str):
    return {"casa": ctx.Casa, "departamento": ctx.Departamento}[tipo]


# ---------------------------------------------------------------- ABox efímera
def _afirmar_inmueble(ctx: _Ctx, inm: dict):
    tipos = inm.get("tipos") or [inm["tipo"]]
    with ctx.eph:
        ind = _clase_tipo(ctx, tipos[0].lower())(inm["id"])
        for t in tipos[1:]:
            ind.is_a.append(_clase_tipo(ctx, t.lower()))
        ind.precio = float(inm["precio"])
        ind.habitaciones = int(inm["habitaciones"])
        ind.banos = int(inm.get("banos", 0))
        ind.metrosCuadrados = float(inm.get("metros_cuadrados", 0))
        ind.estacionamiento = bool(inm.get("estacionamiento", False))
        zona_id = "zona_" + "".join(ch for ch in inm.get("zona", "sin_zona") if ch.isalnum())
        ubic = ctx.world[ctx.eph.base_iri + zona_id] or ctx.Ubicacion(zona_id)
        ubic.nombreZona = inm.get("zona", "")
        ind.estaUbicadoEn = ubic
    return ind


def _afirmar_cliente(ctx: _Ctx, perfil: dict, solicitud_id: str):
    with ctx.eph:
        cli = ctx.Cliente(f"cliente_{solicitud_id}")
        cli.presupuestoMaximo = float(perfil["max_precio"])
        cli.minHabitaciones = int(perfil.get("min_habs", 0))
        cli.requiereEstacionamiento = bool(perfil.get("requiere_estacionamiento", False))
        reqs = [f"presupuesto <= {perfil['max_precio']}"]
        if perfil.get("min_habs"):
            reqs.append(f"habitaciones >= {perfil['min_habs']}")
        for t in perfil.get("tipos_requeridos") or []:
            reqs.append(f"tipo = {t}")
        for i, texto in enumerate(reqs):
            r = ctx.Requisito(f"req_{solicitud_id}_{i}")
            r.descripcionRequisito = [texto]
            cli.tieneRequisito.append(r)
        for i, zona in enumerate(perfil.get("zonas_preferidas") or []):
            p = ctx.Preferencia(f"pref_{solicitud_id}_{i}")
            p.descripcionPreferencia = [f"zona = {zona}"]
            cli.tienePreferencia.append(p)
    return cli


def _afirmar_recomendaciones(ctx: _Ctx, cli, individuos: dict, recomendados: list[str]):
    with ctx.eph:
        for i, pid in enumerate(recomendados):
            rec = ctx.Recomendacion(f"rec_{i}_{pid}")
            rec.recomiendaInmueble = individuos[pid]
            rec.dirigidaA = cli


def _razonar(ctx: _Ctx) -> bool:
    """True si es consistente."""
    try:
        sync_reasoner_hermit(ctx.world, infer_property_values=False, debug=0)
        return True
    except OwlReadyInconsistentOntologyError:
        return False


# ---------------------------------------------------------------- Diagnóstico
def _relajar_y_espejar(ctx: _Ctx) -> dict:
    """Quita AX1-AX5 y crea clases espejo de violación. Devuelve {axioma: clase}."""
    for nombre in ("Cliente", "Inmueble", "Recomendacion"):
        cls = getattr(ctx, nombre)
        for r in [r for r in cls.is_a if isinstance(r, Restriction)]:
            cls.is_a.remove(r)
    for d in list(ctx.world.disjoint_classes()):
        if set(d.entities) == {ctx.Casa, ctx.Departamento}:
            d.destroy()
    espejos = {}
    with ctx.eph:
        def espejo(ax, expr):
            cls = types.new_class(f"Violacion_{ax}", (Thing,))
            cls.equivalent_to.append(expr)
            espejos[ax] = cls
        espejo("AX1", ctx.Cliente & Not(ctx.presupuestoMaximo.some(
            ConstrainedDatatype(float, min_exclusive=0.0))))
        espejo("AX2", ctx.Inmueble & Not(ctx.precio.some(
            ConstrainedDatatype(float, min_exclusive=0.0))))
        espejo("AX3", ctx.Casa & ctx.Departamento)
        espejo("AX5", ctx.Recomendacion & ctx.recomiendaInmueble.some(Not(ctx.InmuebleViable)))
    return espejos


def _diagnosticar(perfil, inmuebles, recomendados, solicitud_id) -> list[dict]:
    ctx = _Ctx()
    if perfil is not None:
        _definir_requisitos(ctx, perfil)
    espejos = _relajar_y_espejar(ctx)
    individuos = {i["id"]: _afirmar_inmueble(ctx, i) for i in inmuebles}
    cli = _afirmar_cliente(ctx, perfil, solicitud_id) if perfil is not None else None
    if recomendados:
        _afirmar_recomendaciones(ctx, cli, individuos, recomendados)
    if not _razonar(ctx):
        return [{"axioma": "?", "texto": "Inconsistencia no localizada por el diagnóstico",
                 "individuo": None}]
    violaciones = []
    for ax, cls in espejos.items():
        for ind in cls.instances():
            v = {"axioma": ax, "texto": AXIOMAS[ax], "individuo": ind.name}
            if ax == "AX5":
                inm = ind.recomiendaInmueble
                v["inmueble"] = inm.name
                v["motivos"] = [REQUISITOS[n] for n in REQUISITOS
                                if isinstance(inm, getattr(ctx, n))]
            violaciones.append(v)
    return violaciones


# ---------------------------------------------------------------- API pública
def validar_solicitud(perfil: dict, inmuebles: list[dict], recomendados: list[str] | None = None,
                      solicitud_id: str = "s") -> dict:
    """Valida una solicitud (y opcionalmente una recomendación propuesta) con HermiT.

    Estados posibles:
      APROBADA        consistente y con al menos un inmueble viable
      SIN_VIABLES     consistente, pero ningún inmueble cumple los requisitos
      INSATISFACIBLE  los requisitos obligatorios se contradicen (InmuebleViable ≡ ⊥)
      INCONSISTENTE   la ABox viola un axioma de la TBox (ver `violaciones`)
    """
    t0 = time.perf_counter()
    with _LOCK:
        ctx = _Ctx()
        usadas = _definir_requisitos(ctx, perfil)
        individuos = {i["id"]: _afirmar_inmueble(ctx, i) for i in inmuebles}
        cli = _afirmar_cliente(ctx, perfil, solicitud_id)
        if recomendados:
            _afirmar_recomendaciones(ctx, cli, individuos, recomendados)
        consistente = _razonar(ctx)

        resultado = {"razonador": "HermiT", "requisitos_materializados": usadas,
                     "viables": [], "excluidos": {}, "violaciones": []}
        if not consistente:
            resultado["estado"] = "INCONSISTENTE"
            resultado["violaciones"] = _diagnosticar(perfil, inmuebles, recomendados, solicitud_id)
        elif ctx.InmuebleViable in set(ctx.world.inconsistent_classes()):
            resultado["estado"] = "INSATISFACIBLE"
            resultado["violaciones"] = [{
                "axioma": "AX3", "texto": AXIOMAS["AX3"], "individuo": f"cliente_{solicitud_id}",
                "detalle": "InmuebleViable es insatisfacible: los tipos requerido "
                           f"{perfil.get('tipos_requeridos')} son clases disjuntas"}]
        else:
            for pid, ind in individuos.items():
                if isinstance(ind, ctx.InmuebleViable):
                    resultado["viables"].append(pid)
                else:
                    resultado["excluidos"][pid] = [REQUISITOS[n] for n in usadas
                                                   if isinstance(ind, getattr(ctx, n))]
            resultado["estado"] = "APROBADA" if resultado["viables"] else "SIN_VIABLES"
    resultado["tiempo_ms"] = round((time.perf_counter() - t0) * 1000, 1)
    return resultado


def validar_inmueble(inmueble: dict | list[dict]) -> dict:
    """Ruta de escritura: un inmueble solo entra al catálogo si es consistente (AX2, AX3).
    Acepta uno o varios inmuebles (carga masiva en una sola ejecución de HermiT)."""
    lista = inmueble if isinstance(inmueble, list) else [inmueble]
    t0 = time.perf_counter()
    with _LOCK:
        ctx = _Ctx()
        for inm in lista:
            _afirmar_inmueble(ctx, inm)
        consistente = _razonar(ctx)
        violaciones = [] if consistente else _diagnosticar(None, lista, None, "inm")
    return {"estado": "VALIDO" if consistente else "INCONSISTENTE", "violaciones": violaciones,
            "razonador": "HermiT", "tiempo_ms": round((time.perf_counter() - t0) * 1000, 1)}


@lru_cache(maxsize=1)
def info_ontologia() -> dict:
    ctx = _Ctx()
    return {"archivo": config.ONTOLOGY_PATH.name,
            "clases": len(list(ctx.base.classes())),
            "propiedades_objeto": len(list(ctx.base.object_properties())),
            "propiedades_datos": len(list(ctx.base.data_properties())),
            "axiomas_duros": list(AXIOMAS)}
