"""Configuración central leída de variables de entorno (.env)."""
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

MONGODB_URI = os.getenv("MONGODB_URI", "").strip()
MONGODB_DB = os.getenv("MONGODB_DB", "inmoia")
# "atlas" si hay URI; "memoria" (mongomock) para pruebas o si no hay conexión.
DB_BACKEND = "atlas" if MONGODB_URI else "memoria"

API_URL = os.getenv("INMOIA_API_URL", "http://127.0.0.1:8000").rstrip("/")
LLM_MODEL = os.getenv("INMOIA_LLM", "anthropic/claude-haiku-5-5")

ONTOLOGY_PATH = ROOT / "ontologia" / "inmoia.owl"
CATALOGO_PATH = ROOT / "data" / "catalogo.json"
CASOS_PATH = ROOT / "data" / "casos_prueba.json"
RESULTS_DIR = ROOT / "results"

# Pesos del consenso ponderado (Proyecto 2, sección 2.1)
PESOS = {"precio": 0.40, "zona": 0.35, "vivienda": 0.25}
CRITERIOS = tuple(PESOS)
