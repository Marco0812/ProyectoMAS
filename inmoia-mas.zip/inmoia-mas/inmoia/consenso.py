"""Consenso ponderado (Proyecto 2, sección 2.2) en Python puro.

Cambio respecto al P2: las restricciones duras (precio máximo, habitaciones
mínimas, tipo, estacionamiento) ya no viven en este código; se movieron a la
ontología y las hace cumplir HermiT (filtrado de axiomas). Aquí solo se
combinan notas blandas:  U(p) = Σ w_c · nota_c(p), con pesos renormalizados
si algún especialista no participa.
"""
from __future__ import annotations

from .config import PESOS


def consenso_ponderado(evaluaciones: dict[str, dict[str, float]], top_n: int = 3,
                       pesos: dict[str, float] | None = None) -> list[dict]:
    """evaluaciones = {criterio: {id: nota 0-100}}. Devuelve el top_n ordenado."""
    pesos = pesos or PESOS
    activos = {c: w for c, w in pesos.items() if c in evaluaciones}
    if not activos:
        return []
    total = sum(activos.values())
    norm = {c: w / total for c, w in activos.items()}

    ids = set.intersection(*(set(evaluaciones[c]) for c in norm))
    salida = []
    for pid in ids:
        suma, aportes = 0.0, {}
        for criterio, peso in norm.items():
            nota = evaluaciones[criterio][pid]
            if not isinstance(nota, (int, float)) or isinstance(nota, bool):
                raise ValueError("Puntuación no numérica")
            if not 0 <= nota <= 100:
                raise ValueError("Puntuación fuera de rango")
            aportes[criterio] = round(peso * nota, 2)
            suma += peso * nota
        salida.append({"id": pid, "puntaje": round(suma, 2), "aportes": aportes})
    salida.sort(key=lambda x: (-x["puntaje"], x["id"]))  # desempate estable por ID
    return salida[:top_n] if top_n else salida
