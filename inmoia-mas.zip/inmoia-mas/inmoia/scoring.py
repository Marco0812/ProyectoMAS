"""Lógica de puntuación de los especialistas A1-A3 (Python puro).

Los agentes LLM no inventan números: invocan su herramienta, el backend
calcula la nota con estas funciones y el agente solo la interpreta.
Las notas son "blandas": un inmueble que excede el presupuesto recibe una
nota baja, pero NO se descarta aquí. Descartar es responsabilidad de la
ontología (A5, Validador Semántico).
"""
from __future__ import annotations


def puntuar_precio(inm: dict, perfil: dict) -> tuple[float, str]:
    maximo = float(perfil["max_precio"])
    if maximo <= 0:
        return 0.0, "presupuesto no válido"
    r = float(inm["precio"]) / maximo
    if r <= 1:
        nota = 60 + 40 * (1 - r)
        motivo = f"usa el {r:.0%} del presupuesto"
    else:
        nota = max(0.0, 55 - 250 * (r - 1))
        motivo = f"excede el presupuesto en {r - 1:.0%}"
    return round(nota, 2), motivo


def puntuar_zona(inm: dict, perfil: dict, sectores: dict[str, str]) -> tuple[float, str]:
    preferidas = perfil.get("zonas_preferidas") or []
    if not preferidas:
        return 70.0, "sin preferencia de zona"
    if inm["zona"] in preferidas:
        return 100.0, f"{inm['zona']} es zona preferida"
    sectores_pref = {sectores.get(z) for z in preferidas}
    if sectores.get(inm["zona"]) in sectores_pref:
        return 60.0, f"{inm['zona']} está en el mismo sector ({sectores[inm['zona']]})"
    return 20.0, f"{inm['zona']} fuera de las zonas preferidas"


def puntuar_vivienda(inm: dict, perfil: dict) -> tuple[float, str]:
    def ratio(valor, deseado):
        return 1.0 if not deseado else min(1.0, float(valor) / float(deseado))

    habs = ratio(inm["habitaciones"], perfil.get("min_habs"))
    banos = ratio(inm.get("banos", 0), perfil.get("banos_deseados"))
    m2 = ratio(inm.get("metros_cuadrados", 0), perfil.get("m2_deseados"))
    est = 1.0 if inm.get("estacionamiento") else (0.0 if perfil.get("requiere_estacionamiento") else 0.7)
    nota = 100 * (0.35 * habs + 0.20 * banos + 0.25 * m2 + 0.20 * est)
    motivo = (f"{inm['habitaciones']} hab, {inm.get('banos', 0)} baños, "
              f"{inm.get('metros_cuadrados', 0):.0f} m², "
              f"{'con' if inm.get('estacionamiento') else 'sin'} estacionamiento")
    return round(nota, 2), motivo


def evaluar(criterio: str, inmuebles: list[dict], perfil: dict,
            sectores: dict[str, str]) -> dict[str, dict]:
    """Devuelve {id: {"puntuacion": float, "motivo": str}} para un criterio."""
    salida = {}
    for inm in inmuebles:
        if criterio == "precio":
            nota, motivo = puntuar_precio(inm, perfil)
        elif criterio == "zona":
            nota, motivo = puntuar_zona(inm, perfil, sectores)
        elif criterio == "vivienda":
            nota, motivo = puntuar_vivienda(inm, perfil)
        else:
            raise ValueError(f"Criterio desconocido: {criterio}")
        salida[inm["id"]] = {"puntuacion": nota, "motivo": motivo}
    return salida
