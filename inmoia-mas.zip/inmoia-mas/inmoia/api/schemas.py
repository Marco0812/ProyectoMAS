"""Esquemas Pydantic: solo validan TIPOS. Las reglas del dominio
(presupuesto positivo, tipos compatibles, etc.) se validan en la ontología."""
from typing import Any, Literal

from pydantic import BaseModel, Field

Tipo = Literal["casa", "departamento"]


class Perfil(BaseModel):
    nombre: str | None = None
    max_precio: float
    min_habs: int = 0
    tipos_requeridos: list[Tipo] = Field(default_factory=list,
                                         description="Cada tipo listado es obligatorio (conjunción)")
    requiere_estacionamiento: bool = False
    zonas_preferidas: list[str] = Field(default_factory=list)
    banos_deseados: int = 0
    m2_deseados: float = 0


class SolicitudIn(BaseModel):
    perfil: Perfil
    run_id: str | None = None


class Inmueble(BaseModel):
    id: str
    tipo: Tipo
    tipos: list[Tipo] | None = Field(None, description="Opcional: varios tipos (para probar AX3)")
    precio: float
    habitaciones: int
    banos: int = 0
    metros_cuadrados: float = 0
    estacionamiento: bool = False
    zona: str
    sector: str | None = None


class PropuestaIn(BaseModel):
    ids: list[str]
    agent_id: str = "A4"


class ExplicacionIn(BaseModel):
    texto: str
    agent_id: str = "A4"


class TrazaIn(BaseModel):
    evento: str
    solicitud_id: str | None = None
    run_id: str | None = None
    agent_id: str | None = None
    task_id: str | None = None
    datos: dict[str, Any] = Field(default_factory=dict)
