"""Backend asíncrono de InmoIA (FastAPI).

Persistencia transaccional en MongoDB (Atlas o memoria) y validación
semántica efímera con HermiT en RAM. Cada endpoint registra su propia
traza de auditoría en la colección `trazas`.

Ejecutar:  uvicorn inmoia.api.main:app --reload
Docs:      http://127.0.0.1:8000/docs
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Request

from .. import config, db, ontologia
from ..consenso import consenso_ponderado
from ..evaluacion import auditoria_shapley
from ..scoring import evaluar
from .schemas import ExplicacionIn, Inmueble, PropuestaIn, SolicitudIn, TrazaIn

SIN_ID = {"_id": 0}
INFERENCIA = ("/validar", "/consenso", "/recomendaciones", "/auditoria/shapley")


def _ahora() -> str:
    return datetime.now(timezone.utc).isoformat()


async def traza(evento: str, solicitud_id: str | None = None, **datos):
    await db.get_db()["trazas"].insert_one(
        {"ts": _ahora(), "evento": evento, "solicitud_id": solicitud_id, **datos})


async def _sectores() -> dict:
    return json.loads(config.CATALOGO_PATH.read_text(encoding="utf-8"))["sectores"]


async def sembrar_catalogo(forzar: bool = False) -> int:
    """Carga data/catalogo.json si la colección está vacía (validado por HermiT)."""
    coll = db.get_db()["propiedades"]
    if not forzar and await coll.count_documents({}) > 0:
        return 0
    inmuebles = json.loads(config.CATALOGO_PATH.read_text(encoding="utf-8"))["inmuebles"]
    res = await asyncio.to_thread(ontologia.validar_inmueble, inmuebles)
    if res["estado"] != "VALIDO":
        raise RuntimeError(f"Catálogo inconsistente: {res['violaciones']}")
    await coll.delete_many({})
    await coll.insert_many([dict(i) for i in inmuebles])
    return len(inmuebles)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await db.crear_indices()
    await sembrar_catalogo()
    yield


app = FastAPI(title="InmoIA — Sistema Multiagente", version="1.0.0", lifespan=lifespan,
              description="Asesor inmobiliario multiagente: CrewAI + FastAPI + MongoDB + OWL 2/HermiT")


@app.middleware("http")
async def medir(request: Request, call_next):
    t0 = time.perf_counter()
    resp = await call_next(request)
    ms = round((time.perf_counter() - t0) * 1000, 2)
    ruta = request.url.path
    if not ruta.startswith(("/auditoria/trazas", "/auditoria/metricas", "/docs", "/openapi")):
        categoria = "inferencia" if any(k in ruta for k in INFERENCIA) else "crud"
        if request.method in ("POST", "PUT") and ruta.startswith("/propiedades"):
            categoria = "crud+inferencia"
        await traza("http", None, metodo=request.method, ruta=ruta, status=resp.status_code,
                    duracion_ms=ms, categoria=categoria)
    resp.headers["X-Duracion-ms"] = str(ms)
    return resp


# ------------------------------------------------------------------ Salud
@app.get("/health", tags=["sistema"])
async def health():
    return {"api": "ok", "mongo": await db.ping(),
            "ontologia": await asyncio.to_thread(ontologia.info_ontologia),
            "propiedades": await db.get_db()["propiedades"].count_documents({})}


# ------------------------------------------------------------------ CRUD
@app.get("/propiedades", tags=["catálogo"])
async def listar_propiedades(zona: str | None = None):
    filtro = {"zona": zona} if zona else {}
    return await db.get_db()["propiedades"].find(filtro, SIN_ID).sort("id", 1).to_list()


@app.get("/propiedades/{pid}", tags=["catálogo"])
async def obtener_propiedad(pid: str):
    doc = await db.get_db()["propiedades"].find_one({"id": pid}, SIN_ID)
    if not doc:
        raise HTTPException(404, f"No existe {pid}")
    return doc


async def _validar_y_guardar(inm: Inmueble, reemplazar: bool):
    datos = inm.model_dump(exclude_none=True)
    res = await asyncio.to_thread(ontologia.validar_inmueble, datos)
    await traza("validacion_inmueble", None, propiedad_id=inm.id, agent_id="A5",
                estado=res["estado"], violaciones=res["violaciones"], duracion_ms=res["tiempo_ms"])
    if res["estado"] != "VALIDO":
        raise HTTPException(422, {"mensaje": "Rechazado por la ontología", **res})
    datos.pop("tipos", None)
    coll = db.get_db()["propiedades"]
    if reemplazar:
        await coll.replace_one({"id": inm.id}, datos, upsert=True)
    else:
        if await coll.find_one({"id": inm.id}):
            raise HTTPException(409, f"{inm.id} ya existe")
        await coll.insert_one(dict(datos))
    return {"estado": "guardado", "validacion": res, "inmueble": datos}


@app.post("/propiedades", status_code=201, tags=["catálogo"])
async def crear_propiedad(inm: Inmueble):
    return await _validar_y_guardar(inm, reemplazar=False)


@app.put("/propiedades/{pid}", tags=["catálogo"])
async def actualizar_propiedad(pid: str, inm: Inmueble):
    if pid != inm.id:
        raise HTTPException(400, "El id del cuerpo no coincide con la ruta")
    return await _validar_y_guardar(inm, reemplazar=True)


@app.delete("/propiedades/{pid}", tags=["catálogo"])
async def borrar_propiedad(pid: str):
    r = await db.get_db()["propiedades"].delete_one({"id": pid})
    if r.deleted_count == 0:
        raise HTTPException(404, f"No existe {pid}")
    return {"estado": "borrado", "id": pid}


# ------------------------------------------------------------------ Solicitudes
async def _solicitud(sid: str) -> dict:
    doc = await db.get_db()["solicitudes"].find_one({"id": sid}, SIN_ID)
    if not doc:
        raise HTTPException(404, f"No existe la solicitud {sid}")
    return doc


@app.post("/solicitudes", status_code=201, tags=["solicitudes"])
async def crear_solicitud(body: SolicitudIn):
    sid = "S" + uuid.uuid4().hex[:8]
    doc = {"id": sid, "run_id": body.run_id or sid, "perfil": body.perfil.model_dump(),
           "estado": "CREADA", "creada": _ahora()}
    await db.get_db()["solicitudes"].insert_one(dict(doc))
    await traza("inicio_caso", sid, run_id=doc["run_id"], perfil=doc["perfil"])
    return doc


@app.get("/solicitudes/{sid}", tags=["solicitudes"])
async def obtener_solicitud(sid: str):
    return await _solicitud(sid)


@app.post("/solicitudes/{sid}/validar", tags=["agentes"])
async def validar_solicitud(sid: str):
    """A5 — Validador Semántico: HermiT valida la solicitud contra la TBox."""
    sol = await _solicitud(sid)
    catalogo = await listar_propiedades()
    res = await asyncio.to_thread(ontologia.validar_solicitud, sol["perfil"], catalogo, None, sid)
    await db.get_db()["solicitudes"].update_one(
        {"id": sid}, {"$set": {"estado": res["estado"], "validacion": res}})
    await traza("llamada_tool", sid, agent_id="A5", nombre_tool="validar_solicitud",
                salida={"estado": res["estado"], "viables": res["viables"]},
                violaciones=res["violaciones"], duracion_ms=res["tiempo_ms"])
    return {"solicitud_id": sid, **res}


@app.post("/solicitudes/{sid}/evaluar/{criterio}", tags=["agentes"])
async def evaluar_criterio(sid: str, criterio: str):
    """A1/A2/A3 — evalúa SOLO los inmuebles que la ontología declaró viables."""
    if criterio not in config.CRITERIOS:
        raise HTTPException(400, f"Criterio inválido; use {config.CRITERIOS}")
    sol = await _solicitud(sid)
    if sol["estado"] not in ("APROBADA", "EVALUANDO"):
        raise HTTPException(409, {"mensaje": "Operación frenada por el Validador Semántico",
                                  "estado": sol["estado"],
                                  "violaciones": sol.get("validacion", {}).get("violaciones", [])})
    viables = set(sol["validacion"]["viables"])
    candidatos = [p for p in await listar_propiedades() if p["id"] in viables]
    notas = evaluar(criterio, candidatos, sol["perfil"], await _sectores())
    agente = {"precio": "A1", "zona": "A2", "vivienda": "A3"}[criterio]
    await db.get_db()["evaluaciones"].replace_one(
        {"solicitud_id": sid, "criterio": criterio},
        {"solicitud_id": sid, "criterio": criterio, "agent_id": agente, "notas": notas}, upsert=True)
    await db.get_db()["solicitudes"].update_one({"id": sid}, {"$set": {"estado": "EVALUANDO"}})
    for pid, n in notas.items():
        await traza("evaluacion", sid, agent_id=agente, propiedad_id=pid, criterio=criterio,
                    puntuacion=n["puntuacion"], motivo=n["motivo"])
    return {"solicitud_id": sid, "criterio": criterio, "agent_id": agente, "notas": notas}


async def _guardar_recomendacion(sid: str, sol: dict, ids: list[str], agente: str) -> dict:
    """Guardia semántica (AX5): ninguna recomendación se persiste sin HermiT."""
    catalogo = await listar_propiedades()
    por_id = {p["id"]: p for p in catalogo}
    faltan = [i for i in ids if i not in por_id]
    if faltan:
        raise HTTPException(422, {"mensaje": "IDs inexistentes (posible alucinación)", "ids": faltan})
    res = await asyncio.to_thread(ontologia.validar_solicitud, sol["perfil"],
                                  [por_id[i] for i in ids], ids, sid)
    await traza("validacion_recomendacion", sid, agent_id="A5", propuesta_de=agente, ids=ids,
                estado=res["estado"], violaciones=res["violaciones"], duracion_ms=res["tiempo_ms"])
    if res["estado"] == "INCONSISTENTE":
        raise HTTPException(422, {"mensaje": "Recomendación rechazada por la ontología", **res})
    return res


@app.post("/solicitudes/{sid}/consenso", tags=["agentes"])
async def consenso(sid: str):
    """A4 — Integrador: consenso ponderado + guardia AX5 antes de persistir."""
    sol = await _solicitud(sid)
    if sol["estado"] not in ("EVALUANDO", "RECOMENDADA"):
        raise HTTPException(409, {"mensaje": "La solicitud no tiene evaluaciones válidas",
                                  "estado": sol["estado"]})
    docs = await db.get_db()["evaluaciones"].find({"solicitud_id": sid}, SIN_ID).to_list()
    evals = {d["criterio"]: d["notas"] for d in docs}
    faltan = [c for c in config.CRITERIOS if c not in evals]
    if faltan:
        raise HTTPException(409, {"mensaje": "Faltan evaluaciones; no se inventan", "faltan": faltan})
    top3 = consenso_ponderado({c: {k: v["puntuacion"] for k, v in n.items()} for c, n in evals.items()})
    for r in top3:
        r["motivos"] = {c: evals[c][r["id"]]["motivo"] for c in evals}
    guardia = await _guardar_recomendacion(sid, sol, [r["id"] for r in top3], "A4")
    await db.get_db()["recomendaciones"].replace_one(
        {"solicitud_id": sid}, {"solicitud_id": sid, "top3": top3, "creada": _ahora(),
                                "validacion_ax5": guardia["estado"]}, upsert=True)
    await db.get_db()["solicitudes"].update_one({"id": sid}, {"$set": {"estado": "RECOMENDADA"}})
    await traza("llamada_tool", sid, agent_id="A4", nombre_tool="consenso_inmobiliario",
                salida={"top3": [r["id"] for r in top3]})
    await traza("recomendacion", sid, ids_ordenados=[r["id"] for r in top3],
                puntuaciones=[r["puntaje"] for r in top3],
                condiciones_descartadas=sol["validacion"]["excluidos"])
    return {"solicitud_id": sid, "estado": "ok", "top3": top3, "pesos": config.PESOS,
            "validacion_ax5": guardia["estado"]}


@app.post("/solicitudes/{sid}/recomendaciones", tags=["agentes"])
async def proponer_recomendacion(sid: str, body: PropuestaIn):
    """Permite que un agente proponga IDs concretos; HermiT los acepta o rechaza (AX5)."""
    sol = await _solicitud(sid)
    res = await _guardar_recomendacion(sid, sol, body.ids, body.agent_id)
    return {"solicitud_id": sid, "aceptada": True, **res}


@app.post("/solicitudes/{sid}/explicacion", tags=["agentes"])
async def guardar_explicacion(sid: str, body: ExplicacionIn):
    await _solicitud(sid)
    await db.get_db()["recomendaciones"].update_one(
        {"solicitud_id": sid}, {"$set": {"explicacion": body.texto}}, upsert=True)
    await traza("fin_caso", sid, agent_id=body.agent_id, estado_final="RECOMENDADA")
    return {"solicitud_id": sid, "estado": "explicacion_guardada"}


@app.get("/solicitudes/{sid}/recomendacion", tags=["solicitudes"])
async def obtener_recomendacion(sid: str):
    doc = await db.get_db()["recomendaciones"].find_one({"solicitud_id": sid}, SIN_ID)
    if not doc:
        raise HTTPException(404, "Sin recomendación")
    return doc


# ------------------------------------------------------------------ Auditoría
@app.post("/auditoria/trazas", status_code=201, tags=["auditoría"])
async def registrar_traza(t: TrazaIn):
    await traza(t.evento, t.solicitud_id, run_id=t.run_id, agent_id=t.agent_id,
                task_id=t.task_id, **t.datos)
    return {"estado": "registrada"}


@app.get("/auditoria/trazas", tags=["auditoría"])
async def listar_trazas(solicitud_id: str | None = None, evento: str | None = None,
                        limit: int = 200):
    filtro = {k: v for k, v in {"solicitud_id": solicitud_id, "evento": evento}.items() if v}
    return await db.get_db()["trazas"].find(filtro, SIN_ID).sort("ts", -1).limit(limit).to_list()


@app.get("/auditoria/metricas", tags=["auditoría"])
async def metricas():
    """Tiempos promedio por categoría (CRUD vs inferencia) a partir de las trazas http."""
    docs = await db.get_db()["trazas"].find({"evento": "http"}, SIN_ID).to_list()
    salida: dict[str, dict] = {}
    for d in docs:
        c = salida.setdefault(d["categoria"], {"n": 0, "total_ms": 0.0, "max_ms": 0.0})
        c["n"] += 1
        c["total_ms"] += d["duracion_ms"]
        c["max_ms"] = max(c["max_ms"], d["duracion_ms"])
    for c in salida.values():
        c["promedio_ms"] = round(c.pop("total_ms") / c["n"], 2)
    return salida


@app.post("/auditoria/shapley", tags=["auditoría"])
async def calcular_shapley():
    res = await asyncio.to_thread(auditoria_shapley)
    doc = {"creado": _ahora(), **res}
    await db.get_db()["shapley"].insert_one(dict(doc))
    return doc


@app.get("/auditoria/shapley", tags=["auditoría"])
async def ultimo_shapley():
    docs = await db.get_db()["shapley"].find({}, SIN_ID).sort("creado", -1).limit(1).to_list()
    if not docs:
        raise HTTPException(404, "Aún no se calcula; use POST /auditoria/shapley")
    return docs[0]
