"""Evaluación de desempeño y auditoría por coaliciones (Proyecto 2, sección 3).

Simula cada coalición S ⊆ N = {A1..A5} sobre los mismos casos de prueba,
con la misma lógica de herramientas que usan los agentes reales
(scoring.py, consenso.py y HermiT para A5). La parte generativa del LLM
no se re-ejecuta 32×K veces: el integrador se modela por los hechos
verificables que su herramienta le entrega.

  q_k(S) = 50·V + 30·R + 20·E          v(S) = promedio_k q_k(S)
  V: fracción del top-3 que cumple TODOS los requisitos obligatorios
  R: fracción de preferencias (zona, baños, m²) que cumple el top-1
  E: fracción de hechos verificables que la explicación puede sustentar
     {precio, zona, vivienda, requisitos}
"""
from __future__ import annotations

import json
from functools import lru_cache

from . import config, ontologia
from .consenso import consenso_ponderado
from .scoring import evaluar
from .shapley import valores_shapley

AGENTES = {
    "A1": "Analista de Precio",
    "A2": "Analista de Zona",
    "A3": "Analista de Vivienda",
    "A4": "Integrador de Recomendaciones",
    "A5": "Validador Semántico",
}
CRITERIO_DE = {"A1": "precio", "A2": "zona", "A3": "vivienda"}
HECHOS = ("precio", "zona", "vivienda", "requisitos")


def cargar_datos():
    cat = json.loads(config.CATALOGO_PATH.read_text(encoding="utf-8"))
    casos = json.loads(config.CASOS_PATH.read_text(encoding="utf-8"))
    return cat["inmuebles"], cat["sectores"], casos


# ---------- Oráculo externo (independiente de la ontología) ----------
def cumple_requisitos(inm: dict, perfil: dict) -> bool:
    tipos = perfil.get("tipos_requeridos") or []
    return (inm["precio"] <= perfil["max_precio"]
            and inm["habitaciones"] >= perfil.get("min_habs", 0)
            and all(inm["tipo"] == t for t in tipos)
            and (inm["estacionamiento"] or not perfil.get("requiere_estacionamiento")))


def preferencias_cumplidas(inm: dict, perfil: dict) -> float:
    checks = [inm["zona"] in (perfil.get("zonas_preferidas") or []),
              inm["banos"] >= perfil.get("banos_deseados", 0),
              inm["metros_cuadrados"] >= perfil.get("m2_deseados", 0)]
    return sum(checks) / len(checks)


# ---------- Simulación de una coalición ----------
@lru_cache(maxsize=None)
def _viables_hermit(caso_id: str) -> tuple[str, ...]:
    inmuebles, _, casos = cargar_datos()
    caso = next(c for c in casos["validos"] + casos["rechazo"] if c["id"] == caso_id)
    r = ontologia.validar_solicitud(caso["perfil"], inmuebles, solicitud_id=caso_id)
    return tuple(r["viables"])


def ejecutar_coalicion(coalicion: frozenset, caso: dict, inmuebles, sectores) -> dict:
    perfil = caso["perfil"]
    criterios = [CRITERIO_DE[a] for a in sorted(coalicion) if a in CRITERIO_DE]
    if not criterios:
        return {"top3": [], "hechos": set()}
    candidatos = inmuebles
    if "A5" in coalicion:
        viables = set(_viables_hermit(caso["id"]))
        candidatos = [i for i in inmuebles if i["id"] in viables]
    evaluaciones = {c: {k: v["puntuacion"] for k, v in evaluar(c, candidatos, perfil, sectores).items()}
                    for c in criterios}
    top3 = [r["id"] for r in consenso_ponderado(evaluaciones, top_n=3)]
    hechos = set()
    if "A4" in coalicion and top3:  # sin integrador: ranking determinista, E = 0
        hechos = set(criterios) | ({"requisitos"} if "A5" in coalicion else set())
    return {"top3": top3, "hechos": hechos}


def calidad(salida: dict, caso: dict, por_id: dict) -> dict:
    top3 = salida["top3"]
    if not top3:
        return {"V": 0.0, "R": 0.0, "E": 0.0, "q": 0.0}
    perfil = caso["perfil"]
    V = sum(cumple_requisitos(por_id[i], perfil) for i in top3) / len(top3)
    R = preferencias_cumplidas(por_id[top3[0]], perfil)
    E = len(salida["hechos"] & set(HECHOS)) / len(HECHOS)
    return {"V": V, "R": R, "E": E, "q": 50 * V + 30 * R + 20 * E}


def funcion_caracteristica():
    inmuebles, sectores, casos = cargar_datos()
    por_id = {i["id"]: i for i in inmuebles}
    validos = casos["validos"]
    detalle: dict[frozenset, dict] = {}

    def v(coalicion: frozenset) -> float:
        qs = [calidad(ejecutar_coalicion(coalicion, c, inmuebles, sectores), c, por_id)
              for c in validos]
        prom = {k: sum(q[k] for q in qs) / len(qs) for k in ("V", "R", "E", "q")}
        detalle[coalicion] = prom
        return prom["q"]
    return v, detalle


def auditoria_shapley() -> dict:
    v, detalle = funcion_caracteristica()
    jugadores = list(AGENTES)
    phi = valores_shapley(jugadores, v)
    gran = frozenset(jugadores)
    v_n = v(gran)
    return {
        "agentes": AGENTES,
        "phi": {k: round(x, 3) for k, x in phi.items()},
        "v_N": round(v_n, 3),
        "suma_phi": round(sum(phi.values()), 3),
        "casos": len(cargar_datos()[2]["validos"]),
        "coaliciones": {"+".join(sorted(s)) or "∅": {k: round(x, 3) for k, x in d.items()}
                        for s, d in sorted(detalle.items(), key=lambda kv: (len(kv[0]), sorted(kv[0])))},
        "metodo": "Shapley exacto sobre 32 coaliciones simuladas; v(S) = promedio de q sobre casos válidos",
    }
